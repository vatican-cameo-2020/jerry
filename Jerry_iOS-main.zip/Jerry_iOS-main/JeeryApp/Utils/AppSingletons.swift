//
//  AppSingletons.swift
//  JeeryApp
//
//  Created by John on 03/05/21.
//

import Foundation
