//
//  tvcViewUserCell.swift
//  JeeryApp
//
//  Created by daisy on 03/04/21.
//

import UIKit

class tvcViewUserCell: UITableViewCell {

    @IBOutlet weak var imgMarker: UIImageViewX!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblitem: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgUser: UIImageViewX!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
