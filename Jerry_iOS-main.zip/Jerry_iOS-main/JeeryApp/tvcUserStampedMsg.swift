//
//  tvcUserStampedMsg.swift
//  JeeryApp
//
//  Created by daisy on 15/04/21.
//

import UIKit

class tvcUserStampedMsg: UITableViewCell {

    @IBOutlet weak var viewMsg: UIViewX!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblUserMsg: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        bounds()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func bounds(){
        viewMsg.layer.cornerRadius = 15
        viewMsg.layer.maskedCorners = [.layerMinXMaxYCorner,.layerMaxXMinYCorner,.layerMinXMinYCorner]
    }

}
