//
//  ProfileVC.swift
//  JeeryApp
//
//  Created by daisy on 08/04/21.
//

import UIKit
import MaterialTextField

class ProfileVC: BaseViewController{
    
    //MARK:- Outlets
    @IBOutlet weak var tfName: MFTextField!
    @IBOutlet weak var tfBirthday: MFTextField!
    @IBOutlet weak var imgUser: UIImageViewX!
    @IBOutlet weak var tfContactNumber: MFTextField!
    @IBOutlet weak var tfAddress: MFTextField!
    @IBOutlet weak var vwContactNumber: UIView!
    
    //MARK:- Properties
    var authVM = AuthVM.init()
    var imageData: Data?
    var dobPicker = UIDatePicker()
    
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpDobPicker()
        setProfileData()
        //observeProfileResponse()
    
    }
    
    //MARK:- Userdefined Functions
    func setProfileData(){
        if let user = fetchUserData(){
            if let url = URL(string: user.profilePicture){
                imgUser.sd_setImage(with: url, placeholderImage: Constants.AppAssets.userAvtar, options: .scaleDownLargeImages, completed: nil)
            }
            tfName.text = fetchUserData()?.name ?? ""
            tfBirthday.text =  fetchUserData()?.birthday?.getFormattedDate("dd MMM, yyyy")
            tfContactNumber.text = fetchUserData()?.contactNumber ?? ""
            tfAddress.text = fetchUserData()?.address ?? ""
            tfContactNumber.isUserInteractionEnabled = false
            //vwContactNumber.isHidden = fetchUserData()?.loginType != .Email
            dobPicker.date = fetchUserData()?.birthday ?? Date()
        }
    }
    
    //MARK:- Set Birthday Picker
    func setUpDobPicker(){
        dobPicker.datePickerMode = .date
        dobPicker.maximumDate = Date()
       
        if #available(iOS 13.4, *) {
            dobPicker.preferredDatePickerStyle = .wheels
        }
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        toolbar.tintColor = Constants.AppAssets.themeGrey
        let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedobPicker))
        toolbar.setItems([cancelButton,spaceButton,doneButton], animated: false)
        //toolbar.tintColor = .systemBlue
        tfBirthday.inputAccessoryView = toolbar
        tfBirthday.inputView = dobPicker
    }
    
    //MARK:- Button Actions
    //Date Picker Toolbar
    @IBAction func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    @IBAction func donedobPicker(){
        tfBirthday.text = dobPicker.date.getFormattedDate("dd MMM, yyyy")
        self.view.endEditing(true)
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnAddPic(_ sender: UIButton) {
        self.presentPickerSelector()
    }
    
    @IBAction func btnSave(_ sender: UIButtonX) {
        showProgress()
        if imageData != nil{
            self.uploadProfileImage()
        }else{
            let request = UserDetails(userId: fetchUserData()?.userId ?? "", email: fetchUserData()?.email ?? "", name: (tfName.text ?? ""), profilePicture: fetchUserData()?.profilePicture ?? "", contactNumber: tfContactNumber.text ?? "", loginType: fetchUserData()?.loginType ?? .Email, fcmToken: fetchUserData()?.fcmToken ?? "", birthday: dobPicker.date, address: tfAddress.text ?? "", latitude: "", longitude: "")
            self.updateUserProfile(request)
        }
    }
    
    @IBAction func tfEditingChanged(_ sender: UITextField) {
    }
    
    //MARK:- Firebase Observers
//    func observeProfileResponse(){
//        authVM.isLoading.subscribe { (isLoading) in
//            isLoading ? self.showProgress() : self.hideProgress()
//        }.disposed(by: authVM.disposeBag)
//
//        authVM.response.subscribe(onNext: { response in
//            if response?.statusCode == 200{
//                if response?.authRespType == .Edit_Profile {
//                    self.toast(Constants.AppStrings.profileUpdated)
//                }
//                else if response?.authRespType == .Upload_Picture{
//                    let request = UserDetails(userId: fetchUserData()?.userId ?? "", email: fetchUserData()?.email ?? "", name: (self.tfName.text ?? ""), profilePicture: response?.imageUrl ?? "", contactNumber: self.tfContactNumber.text ?? "", loginType: fetchUserData()?.loginType ?? .Email, fcmToken: fetchUserData()?.fcmToken ?? "", birthday: self.dobPicker.date, address: self.tfAddress.text ?? "", latitude: "", longitude: "")
//                    self.authVM.updateUserProfile(request)
//                }
//            }
//        }) { (error) in
//            self.toast(error.localizedDescription)
//        }.disposed(by: authVM.disposeBag)
//    }
    
    func uploadProfileImage(){
    
        authVM.uploadUserProfileImage(imageData!) { response in
            if response.statusCode == 200{
                let request = UserDetails(userId: fetchUserData()?.userId ?? "", email: fetchUserData()?.email ?? "", name: (self.tfName.text ?? ""), profilePicture: response.imageUrl, contactNumber: self.tfContactNumber.text ?? "", loginType: fetchUserData()?.loginType ?? .Email, fcmToken: fetchUserData()?.fcmToken ?? "", birthday: self.dobPicker.date, address: self.tfAddress.text ?? "", latitude: "", longitude: "")
                self.updateUserProfile(request)
            }
        }
    }
    func updateUserProfile(_ user: UserDetails){
        authVM.updateUserProfile(user) { response in
            self.hideProgress()
            if response.statusCode == 200{
                self.toast(Constants.AppStrings.profileUpdated)
            }else{
                self.toast(response.message)
            }
        }
    }
}

//MARK:- ImagePicker Delgate Protocols
extension ProfileVC{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        var selectedImage: UIImage?
        
        if let editedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage{
            selectedImage = editedImage
        }
        else if let originalImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage{
            selectedImage = originalImage
        }
        
        let data = selectedImage?.jpegData(compressionQuality: 0.5) ?? Data()
        if data.count > (1000 * 1000){
            self.toast(Constants.AppStrings.imageTooBig)
        }else{
            imgUser.image = selectedImage
            imageData = data
        }
        picker.dismiss(animated: true, completion: nil)
    }
}


