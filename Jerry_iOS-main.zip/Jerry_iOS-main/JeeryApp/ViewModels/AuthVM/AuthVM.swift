//
//  RegisterVM.swift
//  EverArk
//
//  Created by Sachtech on 13/10/20.
//  Copyright © 2020 SachTech. All rights reserved.
//

import Foundation
import RxSwift
import FBSDKLoginKit
import GoogleSignIn
import AuthenticationServices
import CryptoKit
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage

class AuthVM: ViewModel<AuthResponse>{
    
    //MARK:- Properties
    let auth = Auth.auth()
    var firestoreRef = Firestore.firestore()
    let storageRef = Storage.storage().reference()
    var loginType: LoginType = .Email
    var socialCreds: AuthCredential?
    var loginForm: LoginForm = LoginForm()
    var appleDisplayName: String = ""
    var registerForm: SignupForm = SignupForm()

    //MARK:- Firebase Authentications
    func checkUserRegisteredAlready(completion: @escaping ((_ response: AuthResponse) -> ())){
        
        if loginForm.email.isValidEmail{
            firestoreRef.collection(FirebaseCollectionKeys.kUsers).whereField(FirebaseFieldKeys.User.email, isEqualTo: loginForm.email)
                .rx
                .getDocuments()
                .subscribe(onNext: { (data) in
                    let usr = data.documents
                    var resp = AuthResponse(statusCode: 200)
                    resp.authRespType = .Check_User_Availablity
                    if usr.isEmpty{
                        resp.userExists = false
                    }else{
                        if let user = usr.first?.data(){
                            self.loginForm.email = user[FirebaseFieldKeys.User.email] as? String ?? ""
                        }
                        
                        resp.userExists = true

                    }
                    completion(resp)
                }, onError: { (error) in
                    completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
                }).disposed(by: disposeBag)
        }else{
            firestoreRef.collection(FirebaseCollectionKeys.kUsers).whereField(FirebaseFieldKeys.User.contactNumber, isEqualTo: loginForm.email)
                .rx
                .getDocuments()
                .subscribe(onNext: { (data) in
                    let usr = data.documents
                    var resp = AuthResponse(statusCode: 200)
                    resp.authRespType = .Check_User_Availablity
                    if usr.isEmpty{
                        resp.userExists = false
                    }else{
                        resp.userExists = true
                        if let user = usr.first?.data(){
                            self.loginForm.email = user[FirebaseFieldKeys.User.email] as? String ?? ""
                        }
                    }
                    completion(resp)
                }, onError: { (error) in
                    completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
                }).disposed(by: disposeBag)
        }
    }

    
    
    
    
    func registerUser(_ registerForm: SignupForm, completion: @escaping ((_ response: AuthResponse) -> ())){
        isLoading.onNext(true)
        auth.rx.createUser(withEmail: registerForm.email, password: registerForm.password)
            .subscribe(onNext: { authResult in
                let resp = AuthResponse(statusCode: 200, authRespType: .Register, authUser: authResult.user, signupForm: registerForm)
                completion(resp)
      
            }, onError: { error in

                completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
    
    func loginUser(completion: @escaping ((_ response: AuthResponse) -> ())){
        
        auth.rx.signIn(withEmail: loginForm.email, password: loginForm.password)
        .subscribe(onNext: { authResult in
            let resp = AuthResponse(statusCode: 200, authRespType: .Login, authUser: authResult.user)
            completion(resp)
        }) { (error) in
            completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
        }.disposed(by: disposeBag)
    }
    
    func socialLogin(completion: @escaping ((_ response: AuthResponse) -> ())){

        if self.socialCreds != nil{
        auth.rx.signInAndRetrieveData(with: socialCreds!)
            .subscribe(onNext: { authResult in
                var userName: String = authResult.user.displayName ?? ""
                if self.loginType == .Apple{
                    userName = self.appleDisplayName
                }

                let form = SignupForm(name: userName, email: authResult.user.email ?? "", phone: authResult.user.phoneNumber ?? "")
                let resp = AuthResponse(statusCode: 200, authRespType: .Login, authUser: authResult.user, signupForm: form)
                completion(resp)
            }) { (error) in
                completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
            }.disposed(by: disposeBag)
        }else{
            completion(AuthResponse(statusCode: 0, message: "Unable to login"))
        }
    }
    
    //MARK:- User Details Add and Fetch
    func addUser(_ registerForm: SignupForm, user: User, completion: @escaping ((_ response: AuthResponse) -> ())){
        let profileImg = user.photoURL?.absoluteString ?? ""
        let userDetails = UserDetails(userId: user.uid, email: registerForm.email, name: registerForm.name, profilePicture: profileImg, contactNumber: registerForm.phone, loginType: self.loginType)
        
        firestoreRef.collection(FirebaseCollectionKeys.kUsers)
            .document(user.uid)
            .rx
            .setData(userDetails.serilize())
            .subscribe(onNext: { (_) in
                saveUserData(userDetails)
                completion(AuthResponse(statusCode: 200, authRespType: .Register))

            }, onError: { (error) in

                completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
    
    //MARK:- User Details Add and Fetch
    func reportIssue(_ issue: String, completion: @escaping ((_ response: AuthResponse) -> ())){
        if let user = fetchUserData(){
            
            let reportData = UserReports(userName: user.name, userId: user.userId, issue: issue, userEmail: user.email, userContactNumber: user.contactNumber, issueCreatedOn: Date().getFormattedDate())
            
            firestoreRef.collection(FirebaseCollectionKeys.kReport)
                .document()
                .rx
                .setData(reportData.serilize())
                .subscribe(onNext: { (_) in
                    completion(AuthResponse(statusCode: 200, authRespType: .Register))

                }, onError: { (error) in

                    completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
                }).disposed(by: disposeBag)
        }
    }
    
    
    func fetchUserDetails(_ user: User?, completion: @escaping ((_ response: AuthResponse) -> ())){
   
        firestoreRef.collection(FirebaseCollectionKeys.kUsers)
        .document(user?.uid ?? "")
        .rx
        .getDocument()
        .subscribe(onNext: { document in
            if let data = document.data(){
                var userDetails = UserDetails.init()
                userDetails.deserilize(values:data)
                saveUserData(userDetails)
                completion(AuthResponse(statusCode: 200))
            }
        }, onError: { error in
            completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
        }).disposed(by: disposeBag)
    }
    
    //MARK:- User Details Add and Fetch
    func updateUserProfile(_ user: UserDetails, completion: @escaping ((_ response: AuthResponse) -> ())){
        isLoading.onNext(true)
        firestoreRef.collection(FirebaseCollectionKeys.kUsers)
            .document(user.userId)
            .rx
            .setData(user.serilize())
            .subscribe(onNext: { (_) in
                saveUserData(user)
                completion(AuthResponse(statusCode: 200, authRespType: .Edit_Profile))
            }, onError: { (error) in
                completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
    
    
    //MARK:- Upload Profile Picture
    func uploadUserProfileImage(_ data: Data, completion: @escaping ((_ response: AuthResponse) -> ())){
    
        storageRef.child("\(fetchUserData()?.userId ?? "")/\(Constants.PrefKeys.kProfilePicture)").rx
            .putData(data)
            .subscribe(onNext: { metadata in
                self.getDownloadFileUrl() { resp in
                    if resp.statusCode == 200{
                        completion(resp)
                    }else{
                        completion(AuthResponse(statusCode: 0, message: resp.message))
                    }
                }
            }, onError: { error in
                completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
    
    func getDownloadFileUrl(completion: @escaping ((_ response: AuthResponse) -> ())){
        // Fetch the download URL
        storageRef.child("\(fetchUserData()?.userId ?? "")/\(Constants.PrefKeys.kProfilePicture)").rx.downloadURL()
            .subscribe(onNext: { url in
                completion(AuthResponse(statusCode: 200, authRespType: .Upload_Picture, imageUrl: url.absoluteString))
            }, onError: { error in
                completion(AuthResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
    


    
    //MARK:- Social Logins
    func loginWithFacebook(fromViewController: UIViewController, completion: @escaping ((_ success: Bool, _ creds: AuthCredential?) -> ()))  {
        let loginManager = LoginManager()
        loginManager.logOut()
        loginManager.logIn(permissions: ["public_profile", "email"], from: fromViewController) { (loginResult, error) in

            if error != nil {
                completion(false, nil)
            }
            else if loginResult!.isCancelled {
                completion(false, nil)
            } else {
                guard let userID = loginResult?.token?.userID, let tokenString = loginResult?.token?.tokenString else { return }
                print("User logged in using Facebook!")
                print("userID = \(userID)")
                print("tokenString = \(tokenString)")

                let providerId = userID
                let socialToken = tokenString
                
                let credential = FacebookAuthProvider.credential(withAccessToken: tokenString)
                completion(true, credential)
                //self.socialLogin(credential, type: .Facebook)
//
//                GraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, email, picture.type(large), gender, birthday"]).start { (connection, result, error) in
//                    print("facebook result = ", result)
//
//                    if let error = error {
//                        completion(false, AuthRequest(), error)
//                    }
//                    else if let results = result as? [String:Any]{
//                        let fullName = results["name"] as? String ?? ""
//                        let firstName = results["first_name"] as? String ?? ""
//                        let lastName = results["last_name"] as? String ?? ""
//                        let email = results["email"] as? String ?? ""
//
//                        let req = AuthRequest(email: email, firstName: firstName, lastName: lastName, providerId: providerId, socialToken: socialToken, name: fullName)
//                        completion(true, req, error)
//                    }
//                }
            }
        }
    }
    
    
     func randomNonceString(length: Int = 32) -> String {
        precondition(length > 0)
        let charset: Array<Character> =
            Array("0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._")
        var result = ""
        var remainingLength = length
        
        while remainingLength > 0 {
            let randoms: [UInt8] = (0 ..< 16).map { _ in
                var random: UInt8 = 0
                let errorCode = SecRandomCopyBytes(kSecRandomDefault, 1, &random)
                if errorCode != errSecSuccess {
                }
                return random
            }
            
            randoms.forEach { random in
                if remainingLength == 0 {
                    return
                }
                
                if random < charset.count {
                    result.append(charset[Int(random)])
                    remainingLength -= 1
                }
            }
        }
        
        return result
    }
    
    @available(iOS 13, *)
    func sha256(_ input: String) -> String {
       let inputData = Data(input.utf8)
       let hashedData = SHA256.hash(data: inputData)
       let hashString = hashedData.compactMap {
         return String(format: "%02x", $0)
       }.joined()

       return hashString
     }
}

enum AuthAction{
    case Check_User_Availablity
    case Login
    case Register
    case Edit_Profile
    case Upload_Picture
}
