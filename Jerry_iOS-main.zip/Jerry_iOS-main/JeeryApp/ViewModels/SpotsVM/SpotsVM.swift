//
//  SpotsVM.swift
//  JeeryApp
//
//  Created by Kapil on 27/04/21.
//

import Foundation
import RxSwift
import FirebaseAuth
import FirebaseFirestore
import FirebaseStorage


class SpotsVM: ViewModel<SpotsResponse>{
    
    //MARK:- Properties
    let auth = Auth.auth()
    var firestoreRef = Firestore.firestore()
    var spots: [SpotDetail] = []

    
    //MARK:- User Spots Editing
    //    Add User Spots
    func addSpot(_ spot: SpotDetail, completion: @escaping ((_ response: SpotsResponse) -> ())){
        isLoading.onNext(true)
        let ref = firestoreRef.collection(FirebaseCollectionKeys.kUsers).document(fetchUserData()?.userId ?? "").collection(FirebaseCollectionKeys.kSpots).document()
        
        var selectedSpot = spot
        selectedSpot.spotId = ref.documentID

        ref.rx.setData(selectedSpot.serilize())
            .subscribe(onNext: { (_) in
                completion(SpotsResponse(statusCode: 200, spotRespType: .Add_Spot))
            }, onError: { (error) in

                completion(SpotsResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
    
   
    //Fetch User Spots
    func fetchUserSpots(completion: @escaping ((_ response: SpotsResponse) -> ())){

        firestoreRef.collection(FirebaseCollectionKeys.kUsers).document(fetchUserData()?.userId ?? "").collection(FirebaseCollectionKeys.kSpots)
            .rx
            .getDocuments()
            .subscribe(onNext: { documentArr in
                var spotsArr: [SpotDetail] = []
                for documentData in documentArr.documents{
                    let data = documentData.data()
                    var spotDetails = SpotDetail.init()
                    spotDetails.deserilize(values:data)
                    spotsArr.append(spotDetails)
                }
                self.spots = spotsArr
                completion(SpotsResponse(statusCode: 200, spotRespType: .Get_Spots))
            }, onError: { error in
                completion(SpotsResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
    
    //User Details Add and Fetch
    func updateSpot(_ spot: SpotDetail, completion: @escaping ((_ response: SpotsResponse) -> ())){
        isLoading.onNext(true)
        firestoreRef.collection(FirebaseCollectionKeys.kUsers).document(fetchUserData()?.userId ?? "").collection(FirebaseCollectionKeys.kSpots)
            .document(spot.spotId)
            .rx
            .setData(spot.serilize())
            .subscribe(onNext: { (_) in
                completion(SpotsResponse(statusCode: 200, spotRespType: .Edit_Spot))
            }, onError: { (error) in
                completion(SpotsResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
}

enum SpotAction{
    case Get_Spots
    case Edit_Spot
    case Add_Spot
}
