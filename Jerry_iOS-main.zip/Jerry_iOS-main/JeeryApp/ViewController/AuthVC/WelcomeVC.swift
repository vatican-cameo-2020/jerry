//
//  WelcomeVC.swift
//  JeeryApp
//
//  Created by daisy on 31/03/21.
//

import UIKit

class WelcomeVC: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if AppDefaults.userLogged{
            self.navigateToHome()
        }else{
            DispatchQueue.main.asyncAfter(deadline: .now()+2){
                let _: LoginVC = self.open()
            }
        }
    }
}
