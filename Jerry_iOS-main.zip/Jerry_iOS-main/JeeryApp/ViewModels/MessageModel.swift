//
//  MessageModel.swift
//  JeeryApp
//
//  Created by John on 10/05/21.
//

import Foundation


struct MessageResponse: JsonDeserilizer {
    var statusCode: Int = 0
    var message: String = ""
    
    mutating func deserilize(values: Dictionary<String, Any>?) {
        
    }
}

struct Messages: JsonSerilizer, JsonDeserilizer {
    
    var statusCode: Int = 0
    var roomId: String = ""
    var msgId: String = ""
    var roomType: RoomType = .kStamp
    var msgType: MessageType = .kText
    var msgBody: String = ""
    var fileUrl: String = ""
    var createdAt: Int64 = 0
    var senderId: String = ""
    var senderName: String = ""
    var senderImage: String = ""
    
    func serilize() -> Dictionary<String, Any> {
        
        return [
            FirebaseFieldKeys.Messages.roomId: roomId,
            FirebaseFieldKeys.Messages.msgId: msgId,
            FirebaseFieldKeys.Messages.roomType: roomType,
            FirebaseFieldKeys.Messages.msgType: msgType,
            FirebaseFieldKeys.Messages.msgBody: msgBody,
            FirebaseFieldKeys.Messages.fileUrl: fileUrl,
            FirebaseFieldKeys.Messages.createdAt: createdAt,
            FirebaseFieldKeys.Messages.senderId: senderId,
            FirebaseFieldKeys.Messages.senderName: senderName,
            FirebaseFieldKeys.Messages.senderImage: senderImage
        ]
    }
    
    mutating func deserilize(values: Dictionary<String, Any>?) {
        roomId = values?[FirebaseFieldKeys.Messages.roomId] as? String ?? ""
        msgId = values?[FirebaseFieldKeys.Messages.msgId] as? String ?? ""
        roomType = RoomType(rawValue: values?[FirebaseFieldKeys.Messages.roomType] as? String ?? "") ?? .kStamp
        msgType = MessageType(rawValue: values?[FirebaseFieldKeys.Messages.msgType] as? String ?? "") ?? .kText
        msgBody = values?[FirebaseFieldKeys.Messages.msgBody] as? String ?? ""
        fileUrl = values?[FirebaseFieldKeys.Messages.fileUrl] as? String ?? ""
        createdAt = values?[FirebaseFieldKeys.Messages.createdAt] as? Int64 ?? 0
        senderId = values?[FirebaseFieldKeys.Messages.senderId] as? String ?? ""
        senderName = values?[FirebaseFieldKeys.Messages.senderName] as? String ?? ""
        senderImage = values?[FirebaseFieldKeys.Messages.senderImage] as? String ?? ""
    }
}

enum RoomType: String{
    case kStamp = "stamp"
    case kMessage = "message"
}

enum MessageType: String{
    case kText = "text"
    case kImage = "image"
}
