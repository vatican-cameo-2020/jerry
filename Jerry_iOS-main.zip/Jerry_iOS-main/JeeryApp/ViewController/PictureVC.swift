//
//  PictureVC.swift
//  JeeryApp
//
//  Created by daisy on 08/04/21.
//

import UIKit
protocol OpenCamera {
    func opencamera()
    func openimageGallery()
}
class PictureVC: UIViewController {

    var opencamera : OpenCamera?
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func btnCamera(_ sender: UIButton) {
        dismiss(animated: true, completion:nil)
        opencamera?.opencamera()
    }
    
    @IBAction func openImageGallery(_ sender: UIButton) {
        dismiss(animated: true, completion:nil)
        opencamera?.openimageGallery()
    }
    

}
//extension PictureVC : UIImagePickerControllerDelegate,UINavigationControllerDelegate{
//    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
//        picker.dismiss(animated: true, completion: nil)
//    }
//    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//      guard  let image = info[UIImagePickerController.InfoKey.editedImage] else {
//            return
//        }
//
//    }
//}
