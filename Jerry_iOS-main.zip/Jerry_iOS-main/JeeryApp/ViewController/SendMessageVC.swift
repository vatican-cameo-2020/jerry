//
//  MessageMainVC.swift
//  JeeryApp
//
//  Created by daisy on 06/04/21.
//

import UIKit
import MaterialTextField
import GrowingTextView
import ContactsUI
 
class SendMessageVC: BaseViewController {

    //MARK:- Outlets
    
    @IBOutlet weak var btnConfirm: UIButton!

    @IBOutlet weak var tblLocations: UITableView!
    @IBOutlet weak var tblContactList: DynamicSizeTableView!
    @IBOutlet weak var btnSend: UIButtonX!
    @IBOutlet weak var btnClip: UIButtonX!
    @IBOutlet weak var btnAdd: UIButton!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var tfContactSearch: MFTextField!
    @IBOutlet weak var tfLocation: MFTextField!
    
    //MARK:- Properties
    var contactVM =  ContactsVM.init()
    var contacts: [CNContact] = []
    var spotsVM =  SpotsVM.init()
    var filteredSpots: [SpotDetail] = []
    var messageTo: [CNContact] = []
    var selectedSpot: SpotDetail?
    
    //MARK:- Lifecycles

    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        
        setDelegates()
        fetchUserSpots()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        let dict : Dictionary<String,Any> = ["title":"Message","isback":true]
        NotificationCenter.default.post(name: Constants.NotifNames.changeNavigation, object: dict)
        NotificationCenter.default.addObserver(self, selector: #selector(buttonAction), name: Constants.NotifNames.navigateBackAction, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: Constants.NotifNames.changeNavigation, object: nil)
        NotificationCenter.default.removeObserver(self, name: Constants.NotifNames.navigateBackAction, object: nil)
    }
    
    
    //MARK:- View Controller Delegates
    fileprivate func setUI() {
        tblLocations.isHidden = true
        tblContactList.isHidden = true
        btnAdd.isHidden = true
    }
    
    func setDelegates(){
        self.tblContactList.register(UINib(nibName: Constants.TableCells.contactsTVC, bundle: nil), forCellReuseIdentifier: Constants.TableCells.contactsTVC)
        tblContactList.delegate = self
        tblContactList.dataSource = self
        tfContactSearch.delegate = self
        tfContactSearch.addTarget(self, action: #selector(searchingAction), for: .editingChanged)
   
        self.tblLocations.register(UINib(nibName: Constants.TableCells.spotAddressTVC, bundle: nil), forCellReuseIdentifier: Constants.TableCells.spotAddressTVC)
        tblLocations.delegate = self
        tblLocations.dataSource = self
        tfLocation.delegate = self
        tfLocation.addTarget(self, action: #selector(searchingAction), for: .editingChanged)
        
        self.contacts = contactVM.getContacts()
        tblContactList.reloadData()
    }

    
    //MARK:- Button Actions
    @IBAction func buttonAction(){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSearch(_ sender: UIButton) {
        let contacVC = CNContactPickerViewController()
                  contacVC.delegate = self
        self.present(contacVC, animated: true, completion: nil)
    }
    
    @IBAction func tfSearchContact(_ sender: MFTextField) {
    
    }
    
    @IBAction func btnAdd(_ sender: UIButton) {
    
    }
 
    @IBAction func btnSend(_ sender: UIButtonX) {
    
    }
    
    @IBAction func btnClip(_ sender: UIButtonX) {
    
    }
    
    @IBAction func btnSetLocationOnMap(_ sender: UIButton) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddressMapVC") as! AddressMapVC
        vc.mapDelegate = self
        self.parent?.navigationController?.pushViewController(vc, animated: true)
    }

    //MARK:- Firebase Observer
    func fetchUserSpots(){
        spotsVM.fetchUserSpots { response in
            self.hideProgress()
            if response.statusCode == 200{
                self.filteredSpots = self.spotsVM.spots
                self.tblLocations.reloadData()
            }else{
                self.btnConfirm.isHidden = true
                self.toast(response.message)
            }
        }
    }
}

extension SendMessageVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tblContactList{
            return contacts.count
        }
         else if tableView == tblLocations{
            return filteredSpots.count
        }
         else {
            return 0
         }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == tblContactList{
            let cell = tableView.dequeueReusableCell(withIdentifier: Constants.TableCells.contactsTVC) as! ContactsTVC
            cell.setContactInfo(self.contacts[indexPath.row])
            return cell
        }
        else if tableView == tblLocations {
            let cell = tableView.dequeueReusableCell(withIdentifier: Constants.TableCells.spotAddressTVC, for: indexPath) as! SpotAddressTVC
            cell.setAddresssInfo(self.filteredSpots[indexPath.row])
            return cell
        }else{
            return UITableViewCell()
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == tblContactList{
            onContactSelected(indexPath)
        }
        else if tableView == tblLocations {
        
            tblContactList.isHidden = true
            tblLocations.isHidden = true
            btnAdd.isHidden = true
            btnSearch.isHidden = false
        }
    }
    
    
    fileprivate func onContactSelected(_ indexPath: IndexPath) {
        tblLocations.isHidden = true
        btnAdd.isHidden = true
        btnSearch.isHidden = false
        tblContactList.isHidden = true
        
        if !messageTo.contains(self.contacts[indexPath.row]){
            self.messageTo.append(self.contacts[indexPath.row])
        }
        
        let users = messageTo.map { $0.givenName}
        self.tfContactSearch.text = users.joined(separator: ",") + ","
    }
}
//MARK:- TextView Delgate Protocols

extension SendMessageVC : UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == tfContactSearch{
            tblContactList.isHidden = false
            btnSearch.isHidden = true
            btnAdd.isHidden = true
            tblLocations.isHidden = true
        }
        else{
            tblContactList.isHidden = true
            btnSearch.isHidden = false
            btnAdd.isHidden = true
            tblLocations.isHidden = false
            
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == tfContactSearch{
            tblContactList.isHidden = true
        }else if textField == tfLocation{
            tblLocations.isHidden = true
        }
    }
    
    @objc func searchingAction(_ textField: UITextField) {
        
        if textField == tfContactSearch{
            tblContactList.isHidden = false
            let allContacts = contactVM.getContacts()
            let searchUserArr  =  (textField.text?.trimmingCharacters(in: .whitespaces) ?? "").split(separator: ",")
            let searchText = String(searchUserArr.last ?? "")
            self.contacts = searchText.isEmpty ? allContacts : allContacts.filter({ (contact) -> Bool in
                
                let fullName = contact.givenName
                return fullName.range(of: searchText, options: .caseInsensitive) != nil
            })
            DispatchQueue.main.async {
                self.tblContactList.reloadData()
            }
        }
        
        else if textField == tfLocation{
          
            let searchText  =  textField.text?.trimmingCharacters(in: .whitespaces) ?? ""
            self.filteredSpots = searchText.isEmpty ? spotsVM.spots : spotsVM.spots.filter({ (spot) -> Bool in
                
                let addressName = spot.spotName
                return addressName.range(of: searchText, options: .caseInsensitive) != nil
            })
            DispatchQueue.main.async {
                self.tblLocations.reloadData()
            }
        }
    }
}
extension SendMessageVC: CNContactPickerDelegate{
    
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contact: CNContact) {
        print(contact.phoneNumbers)
        let numbers = contact.phoneNumbers.first
        print((numbers?.value)?.stringValue ?? "")
    }
    
    func contactPickerDidCancel(_ picker: CNContactPickerViewController) {
        self.dismiss(animated: true, completion: nil)
    }
}

extension SendMessageVC: MapViewDelegate{
    func onLocationFetched(_ location: LocationAddress) {
        tfLocation.text = location.address
        selectedSpot = SpotDetail(street: location.street, city: location.city, state: location.state, zip: location.pincode, latitude: location.latitude, longitude: location.longitude, address: location.address)
    }
}
