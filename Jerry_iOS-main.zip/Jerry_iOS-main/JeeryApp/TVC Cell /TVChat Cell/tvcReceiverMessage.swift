//
//  tvcReceiverMessage.swift
//  JeeryApp
//
//  Created by daisy on 10/04/21.
//

import UIKit

class tvcReceiverMessage: UITableViewCell {

    @IBOutlet weak var lblReceiverMessage: UILabel!
    @IBOutlet weak var viewReceiverMessage: UIViewX!
    @IBOutlet weak var lbltime: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
   bounds()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func bounds(){
        viewReceiverMessage.layer.cornerRadius = 15
        viewReceiverMessage.layer.maskedCorners = [.layerMaxXMaxYCorner,.layerMaxXMinYCorner,.layerMinXMinYCorner]
    }
    
}
