//
//  PrivacyProfileVC.swift
//  JeeryApp
//
//  Created by daisy on 19/04/21.
//

import UIKit
import WebKit

enum PoliciesType: String{
    case PrivacyPolicy
    case TermsCondition
}

class TermsPoliciesVC: UIViewController {

    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var webView: WKWebView!
    
    
    var type: PoliciesType = .TermsCondition
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        webView.layer.cornerRadius = 10.0
    }
    
    fileprivate func setupUI() {
        
        var urlString: String = ""
        if type == .TermsCondition{
            lblTitle.text = Constants.AppStrings.termsConditions
            urlString = Constants.SocialKeys.termsConditionsURL
        }
        else{
            lblTitle.text = Constants.AppStrings.privacyPolicy
            urlString = Constants.SocialKeys.privacyPolicyURL
        }
        
        if let url = URL(string: urlString){
            webView.load(URLRequest(url: url))
        }
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}
