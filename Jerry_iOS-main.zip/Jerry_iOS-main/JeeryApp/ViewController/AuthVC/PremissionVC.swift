//
//  PremissionVC.swift
//  JeeryApp
//
//  Created by daisy on 02/04/21.
//

import UIKit

protocol PermissionDelegate{
    func allowPermission()
}

class PremissionVC: UIViewController {
    
    var navigateDelegate: PermissionDelegate?
     
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    @IBAction func btnAllow(_ sender: UIButtonX) {
        dismiss(animated: true){
            self.navigateDelegate?.allowPermission()
        }
        
    }
    @IBAction func btnDismiss(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnNotNow(_ sender: UIButtonX) {
        self.dismiss(animated: true, completion: nil)
    }
}
