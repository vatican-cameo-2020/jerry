//
//  NoChatHomeVC.swift
//  JeeryApp
//
//  Created by daisy on 05/04/21.
//

import UIKit

class NoChatHomeVC: BaseViewController {


    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        let dict : Dictionary<String,Any> = ["title":"Home","isback":false]
        NotificationCenter.default.post(name: Constants.NotifNames.changeNavigation, object: dict)
    }
    
    @IBAction func btnStamp(_ sender: UIButtonX) {        
        let _: StampVC = open()
    }
    
    @IBAction func btnMessage(_ sender: UIButton) {
        let _: SendMessageVC = open()
    }
    
}
