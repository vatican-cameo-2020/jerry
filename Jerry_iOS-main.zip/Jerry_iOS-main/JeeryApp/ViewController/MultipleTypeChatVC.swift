//
//  MultipleTypeChatVC.swift
//  JeeryApp
//
//  Created by daisy on 10/04/21.
//

import UIKit
import GrowingTextView


class MultipleTypeChatVC: UIViewController {
    
    @IBOutlet weak var tvChat: DynamicSizeTableView!
    @IBOutlet weak var tfMessage: GrowingTextView!
    @IBOutlet weak var lblReceiverName: UILabel!
    @IBOutlet weak var imgReceiver: UIImageViewX!
    
    var arrSendMessage = ["Where are you going?I am going to the salon for my haircut. What hairstyle would you like?","Thanks"]
    var arrSendMsgDate = ["Nov 5, 10:25","Nov 7, 09:18"]
    var arrReceieveMessage = ["Hey Fly 9! I was tossing and turning all night! I haven’t slept a wink in 3 days! What’s keeping you up? Nothing, really."]
    var arrReceieveMsgDate = ["Nov 4, 18:03"]
    var arrSendImg = [#imageLiteral(resourceName: "ashish'gf")]
    var arrReceieveImg = [#imageLiteral(resourceName: "model")]
    var arrSendImgDate = ["Nov 6, 10:25"]
    var arrReceieveImgDate = ["Nov 6, 22:25"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setDelegates()
    }
    
    @IBAction func btnBack(_ sender: UIButton) {

        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = mainStoryBoard.instantiateViewController(withIdentifier: "HomeMainVC") as! HomeMainVC
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = vc
        
        self.navigationController?.popToRootViewController(animated: true)
        let index : Int = 1
        NotificationCenter.default.post(name: Constants.NotifNames.navigateToTabBar, object: index)
    }
    
    @IBAction func btnSendMessage(_ sender: UIButtonX) {
    }
    
    func setDelegates(){
        tvChat.delegate = self
        tvChat.dataSource = self
       
    }
}
extension MultipleTypeChatVC : UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 1 {
            return arrSendMessage.count
        }
        else if section == 2 {
            return arrReceieveMessage.count
        }
        else if section == 3 {
            return arrSendImg.count
        }
        else {
            return arrReceieveImg.count
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 1 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "tvcUserMessageSend", for: indexPath) as! tvcUserMessageSend
            cell.lblUserMessage.text = arrSendMessage[indexPath.row]
            cell.lblUserDate.text = arrSendMsgDate[indexPath.row]
            return cell
        }
        else if indexPath.section == 2 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "tvcReceiverMessage", for: indexPath) as! tvcReceiverMessage
            cell.lblReceiverMessage.text = arrReceieveMessage[indexPath.row]
            cell.lbltime.text = arrReceieveMsgDate[indexPath.row]
            return cell
        }
        else if indexPath.section == 3 {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "tvcUserImageSend", for: indexPath) as! tvcUserImageSend
            cell.imgSend.image = arrSendImg[indexPath.row]
            cell.lblImageDate.text = arrSendImgDate[indexPath.row]
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tvcReceiverImageSend", for: indexPath) as! tvcReceiverImageSend
            cell.imgRecieve.image = arrReceieveImg[indexPath.row]
            cell.lblImgRecieve.text = arrReceieveImgDate[indexPath.row]
            return cell
        }
    }
    
}
