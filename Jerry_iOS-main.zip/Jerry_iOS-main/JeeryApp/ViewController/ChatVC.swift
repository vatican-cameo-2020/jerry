//
//  ChatVC.swift
//  JeeryApp
//
//  Created by daisy on 09/04/21.
//

import UIKit
import CoreLocation
class ChatVC: UIViewController, CLLocationManagerDelegate {
    
    let  locationManager = CLLocationManager()
    var LocationLatitude : Double = 0
    var LocationLongitutde : Double = 0
    @IBOutlet weak var lblAlert: UILabel!
    @IBOutlet weak var viewMessageField: UIViewX!
    @IBOutlet weak var btnSend: UIButtonX!
    @IBOutlet weak var viewBlur: UIViewX!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblMsgSenderName: UILabel!
    @IBOutlet weak var lblMsg: UILabel!
    @IBOutlet weak var viewMsg: UIViewX!
    @IBOutlet weak var btnMap: UIButton!
    @IBOutlet weak var imgGroup: UIImageViewX!
    @IBOutlet weak var lblGroupName: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        lblTime.isHidden = true
        viewMessageField.isHidden = true
        btnSend.isHidden = true
        viewMsg.isHidden = true
        let swipeleft = UISwipeGestureRecognizer(target: self, action: #selector(swipeGesture))
        let swiperight = UISwipeGestureRecognizer(target: self, action: #selector(swipeGesture))
        swiperight.direction = .right
        swipeleft.direction = .left
        viewBlur.addGestureRecognizer(swiperight)
        viewBlur.addGestureRecognizer(swipeleft)
        viewBlur.layer.cornerRadius = 15
        viewBlur.layer.maskedCorners = [.layerMaxXMaxYCorner,.layerMaxXMinYCorner,.layerMinXMinYCorner]
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    @objc func swipeGesture(){
        viewBlur.isHidden = true
        lblAlert.isHidden = true
        bounds()
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MultipleTypeChatVC") as! MultipleTypeChatVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnBsck(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func btnMap(_ sender: UIButton) {
//        let cl = CLLocationManager()
//
        let latitude = LocationLatitude
        let longitude = LocationLongitutde
        let directionsURL = "http://maps.apple.com/?ll=\(latitude),\(longitude)"
        guard let url = URL(string: directionsURL) else {
        return
        }
        if #available(iOS 10.0, *) {
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
        UIApplication.shared.openURL(url)
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.first
        let latitudes = location?.coordinate.latitude
        let longitudes = location?.coordinate.longitude
        LocationLatitude = latitudes ?? 0
        LocationLongitutde = longitudes ?? 0
        
    }
    func bounds(){
        viewMsg.layer.cornerRadius = 15
        viewMsg.layer.maskedCorners = [.layerMaxXMaxYCorner,.layerMaxXMinYCorner,.layerMinXMinYCorner]
        
    }
    
}
