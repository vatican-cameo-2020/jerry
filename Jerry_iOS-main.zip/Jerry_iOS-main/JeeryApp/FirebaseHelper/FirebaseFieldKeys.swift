//
//  FirebaseFields.swift
//  JeeryApp
//
//  Created by John on 23/04/21.
//

import Foundation

struct FirebaseFieldKeys {
    //MARK:- Users Table
    struct User{
        static let uid: String = "uid"
        static let name: String = "name"
        static let email: String = "email"
        static let contactNumber: String = "contactNumber"
        static let fcmToken: String = "fcmToken"
        static let socialToken: String = "socialToken"
        static let socialProviderId: String = "socialProviderId"
        static let profilePicture: String = "profilePicture"
        static let birthday: String = "birthday"
        static let address: String = "address"
        static let loginType: String = "loginType"
        static let latitude: String = "latitude"
        static let longitude: String = "longitude"
        
        //CollectionKeys
        static let friends: String = "Friends"
        static let chatLists: String = "ChatLists"
        static let mySpots: String = "MySpots"
        static let notifications: String = "Notifications"
    }
    
    struct Spots{
    
        static let spotId: String = "spotId"
        static let spotName: String = "spotName"
        static let street: String = "street"
        static let city: String = "city"
        static let state: String = "state"
        static let zip: String = "zip"
        static let address: String = "address"
        static let latitude: String = "latitude"
        static let longitude: String = "longitude"
        
    }
    
    struct Messages{
        static let roomId: String = "roomId"
        static let msgId: String = "msgId"
        static let roomType: String = "roomType"
        static let msgType: String = "msgType"
        static let msgBody: String = "msgBody"
        static let fileUrl: String = "fileUrl"
        static let createdAt: String = "createdAt"
        static let senderId: String = "senderId"
        static let senderName: String = "senderName"
        static let senderImage: String = "senderImage"
        static let latitude: String = "latitude"
        static let longitude: String = "longitude"
        static let locationName: String = "locationName"
    }
    
    struct ChatList{
        static let roomId: String = "roomId"
        static let roomType: String = "roomType"
        static let userIds: String = "userIds"
        static let userNames: String = "userNames"
        static let lastMsgBody: String = "msgBody"
        static let createdAt: String = "createdAt"

    }
    
    struct Report{
        static let userName: String = "userName"
        static let userId: String = "userId"
        static let issue: String = "issue"
        static let userEmail: String = "userEmail"
        static let userContactNumber: String = "userContactNumber"
        static let issueCreatedOn: String = "issueCreatedOn"
    }

}
