//
//  SignupForm.swift
//  Camo
//
//  Created by SachTech on 20/02/20.
//  Copyright © 2020 SachTech. All rights reserved.
//

import Foundation

struct SignupForm:Validator {

    var name: String = ""
    var email: String = ""
    var password: String = ""
    var phone: String = ""
    

    func isValid() -> Bool {
        
        return !name.isEmpty && !email.isEmpty && email.isValidEmail && !password.isEmpty && password.isValidPassword && !phone.isEmpty && phone.isValidMobile
    }

    func errorReason() -> (String,ValidatorKeys) {
        if name.isEmpty{
            return (Constants.AppStrings.enterName,ValidatorKeys.kFirstName)
        }
        else if email.isEmpty{
            return (Constants.AppStrings.emptyEmail,ValidatorKeys.kEmail)
        }
        else if !email.isValidEmail{
            return (Constants.AppStrings.notValidEmail,ValidatorKeys.kEmail)
        }
        else if password.isEmpty{
            return (Constants.AppStrings.emptyPassword,ValidatorKeys.kPassword)
        }
        else if !password.isValidPassword{
            return (Constants.AppStrings.notValidPassword,ValidatorKeys.kPassword)
        }
        else if phone.isEmpty{
            return (Constants.AppStrings.emptyPhone,ValidatorKeys.kPhone)
        }
        else if !phone.isValidMobile{
            return (Constants.AppStrings.notValidPhone,ValidatorKeys.kPhone)
        }
        else{
            return (Constants.AppStrings.unknownError,ValidatorKeys.kUnknown)
        }
    }
}
