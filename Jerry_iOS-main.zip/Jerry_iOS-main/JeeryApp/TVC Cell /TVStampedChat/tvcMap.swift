//
//  tvcMap.swift
//  JeeryApp
//
//  Created by daisy on 15/04/21.
//

import UIKit
import MapKit
import CoreLocation

class tvcMap: UITableViewCell, CLLocationManagerDelegate {

    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var btnGetDirection: UIButton!
    @IBOutlet weak var viewMap: MKMapView!
    
    let  locationManager = CLLocationManager()
    var LocationLatitude : Double = 0
    var LocationLongitutde : Double = 0
    
    override func awakeFromNib() {
        super.awakeFromNib()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

  
    }

    @IBAction func btnDirection(_ sender: UIButton) {
        let latitude = LocationLatitude
        let longitude = LocationLongitutde
        let directionsURL = "http://maps.apple.com/?ll=\(latitude),\(longitude)"
        guard let url = URL(string: directionsURL) else {
        return
        }
        if #available(iOS 10.0, *) {
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
        UIApplication.shared.openURL(url)
        }
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            
            let latitudes = location.coordinate.latitude
            let longitudes = location.coordinate.longitude
            LocationLatitude = latitudes 
            LocationLongitutde = longitudes 
            manager.stopUpdatingLocation()
            render(location)
        }
    }
    func render(_ location : CLLocation){
        let coordinates = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let span = MKCoordinateSpan(latitudeDelta: 0.11, longitudeDelta: 0.11)
        let region = MKCoordinateRegion(center: coordinates, span: span)

        viewMap.setRegion(region, animated: true)
        
       
    }

}
