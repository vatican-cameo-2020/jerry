//
//  tvcMessageMainTableViewCell.swift
//  JeeryApp
//
//  Created by daisy on 06/04/21.
//

import UIKit
import ContactsUI

class ContactsTVC: UITableViewCell {

    @IBOutlet weak var lblInitial: UILabel!
    @IBOutlet weak var lblNumber: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var viewBack: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    
    }
    
    func setContactInfo(_ contact: CNContact){
        var fullname = contact.givenName
        fullname = contact.middleName.isEmpty ? fullname : "\(fullname) \(contact.middleName)"
        fullname = contact.familyName.isEmpty ? fullname : "\(fullname) \(contact.familyName)"
        
        lblInitial.text = fullname.getNameInitials()
        lblName.text = fullname
        
        if let numberValue = contact.phoneNumbers.first?.value{
            let countryCode = numberValue.value(forKey: "countryCode") as? String ?? ""
            let digits = numberValue.value(forKey: "digits") as? String ?? ""
            
            lblNumber.text = countryCode.getCountryCode() + "" + digits
        }
    }
}
