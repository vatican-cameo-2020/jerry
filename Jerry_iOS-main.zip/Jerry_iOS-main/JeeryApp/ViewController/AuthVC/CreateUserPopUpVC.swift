//
//  CreateUserPopUpVC.swift
//  JeeryApp
//
//  Created by daisy on 02/04/21.
//

import UIKit

protocol PushScreen{
    func pushScreen()
}
class CreateUserPopUpVC: UIViewController {
    var delegatePush:PushScreen?
    override func viewDidLoad() {
        super.viewDidLoad()

      
    }
    
    @IBAction func btnCreateAccount(_ sender: UIButtonX) {
        dismiss(animated: true, completion: nil)
        delegatePush?.pushScreen()
      
    }
    
    @IBAction func btnDismissAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
}
