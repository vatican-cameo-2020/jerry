//
//  AuthRequest.swift
//  EverArk
//
//  Created by Sachtech on 13/10/20.
//  Copyright © 2020 SachTech. All rights reserved.
//

import Foundation
import FirebaseAuth

struct AuthResponse: JsonDeserilizer {
    var statusCode: Int = 0
    var message: String = ""
    var userExists: Bool = false
    var authRespType: AuthAction = .Check_User_Availablity
    var imageUrl: String = ""
    var authUser: User?
    var signupForm: SignupForm = SignupForm()
 
    
    mutating func deserilize(values: Dictionary<String, Any>?) {
        
    }
}


struct UserDetails: JsonSerilizer, JsonDeserilizer {
    var statusCode: Int = 0
    var userId: String = ""
    var email: String = ""
    var name: String = ""
    var profilePicture: String = ""
    var contactNumber: String = ""
    var loginType: LoginType = .Email
    var fcmToken: String = ""
    var birthday: Date?
    var address: String = ""
    var latitude: String = ""
    var longitude: String = ""
    
    var friends: [String] = []

    func serilize() -> Dictionary<String, Any> {
        return [
            FirebaseFieldKeys.User.uid: userId,
            FirebaseFieldKeys.User.email: email,
            FirebaseFieldKeys.User.name: name,
            FirebaseFieldKeys.User.fcmToken: AppDefaults.fcmToken,
            FirebaseFieldKeys.User.contactNumber: contactNumber,
            FirebaseFieldKeys.User.loginType: loginType.rawValue,
            FirebaseFieldKeys.User.profilePicture: profilePicture,
            FirebaseFieldKeys.User.birthday: birthday?.getFormattedDate() ?? "",
            FirebaseFieldKeys.User.address: address,
            FirebaseFieldKeys.User.latitude: latitude,
            FirebaseFieldKeys.User.longitude: longitude
        ]
    }
    
    mutating func deserilize(values: Dictionary<String, Any>?) {
        userId = values?[FirebaseFieldKeys.User.uid] as? String ?? ""
        name = values?[FirebaseFieldKeys.User.name] as? String ?? ""
        email = values?[FirebaseFieldKeys.User.email] as? String ?? ""
        contactNumber = values?[FirebaseFieldKeys.User.contactNumber] as? String ?? ""
        loginType = LoginType(rawValue: values?[FirebaseFieldKeys.User.loginType] as? String ?? "") ?? .Email
        fcmToken = values?[FirebaseFieldKeys.User.fcmToken] as? String ?? ""
        profilePicture = values?[FirebaseFieldKeys.User.profilePicture] as? String ?? ""
        birthday = (values?[FirebaseFieldKeys.User.birthday] as? String ?? "").toDate()
        address = values?[FirebaseFieldKeys.User.address] as? String ?? ""
        latitude = values?[FirebaseFieldKeys.User.latitude] as? String ?? ""
        longitude = values?[FirebaseFieldKeys.User.longitude] as? String ?? ""
        
        if let arrFriends = values?[FirebaseFieldKeys.User.friends] as? [String]{
            self.friends = arrFriends
        }
    }
}

struct UserReports: JsonSerilizer, JsonDeserilizer {
    var statusCode: Int = 0
    var userName: String = ""
    var userId: String = ""
    var issue: String = ""
    var userEmail: String = ""
    var userContactNumber: String = ""
    var issueCreatedOn: String = ""

    func serilize() -> Dictionary<String, Any> {
        return [
            FirebaseFieldKeys.Report.userName: userName,
            FirebaseFieldKeys.Report.userId: userId,
            FirebaseFieldKeys.Report.issue: issue,
            FirebaseFieldKeys.Report.userEmail: userEmail,
            FirebaseFieldKeys.Report.userContactNumber: userContactNumber,
            FirebaseFieldKeys.Report.issueCreatedOn: issueCreatedOn,
        ]
    }
    
    mutating func deserilize(values: Dictionary<String, Any>?) {
        userName = values?[FirebaseFieldKeys.Report.userName] as? String ?? ""
        userId = values?[FirebaseFieldKeys.Report.userId] as? String ?? ""
        issue = values?[FirebaseFieldKeys.Report.issue] as? String ?? ""
        userEmail = values?[FirebaseFieldKeys.Report.userEmail] as? String ?? ""
        userContactNumber = values?[FirebaseFieldKeys.Report.userContactNumber] as? String ?? ""
        issueCreatedOn = values?[FirebaseFieldKeys.Report.issueCreatedOn] as? String ?? ""
    }
}

enum LoginType: String{
    case Email = "email"
    case Facebook = "facebook"
    case Google = "google"
    case Apple = "apple"
}
