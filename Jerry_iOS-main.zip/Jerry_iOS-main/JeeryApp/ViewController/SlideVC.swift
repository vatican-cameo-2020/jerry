//
//  SlideVC.swift
//  JeeryApp
//
//  Created by daisy on 05/04/21.
//

import UIKit

class SlideVC: BaseViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var tblMenu: DynamicSizeTableView!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var imgUser: UIImageViewX!
    
    //MARK:-
    var arrServiceName = [Constants.AppStrings.addYourSpots, Constants.AppStrings.termsConditions, Constants.AppStrings.privacyPolicy, Constants.AppStrings.reportHelp, Constants.AppStrings.logout]
    var arrImageService =  [#imageLiteral(resourceName: "Icon metro-location"),#imageLiteral(resourceName: "AddUser"),#imageLiteral(resourceName: "icons8-privacy-policy-24"),#imageLiteral(resourceName: "questionMark"),#imageLiteral(resourceName: "logout")]
    var authVM = AuthVM.init()

  //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setDelegates()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        setUserInfo()
    }
    
    //MARK:-
    func setDelegates(){
        let nibName = UINib(nibName: Constants.TableCells.drawerMenuTVC, bundle:nil)
        self.tblMenu.register(nibName, forCellReuseIdentifier: Constants.TableCells.drawerMenuTVC)
        tblMenu.delegate = self
        tblMenu.dataSource = self
    }
    
    func setUserInfo(){
        if let user = fetchUserData(){
            if let url = URL(string: user.profilePicture){
                imgUser.sd_setImage(with: url, placeholderImage: Constants.AppAssets.userAvtar, options: .scaleDownLargeImages, completed: nil)
            }
            lblName.text = fetchUserData()?.name ?? ""
            lblCity.text = fetchUserData()?.address ?? ""
        }
    }
    
    //MARK:- Button Actions
    @IBAction func btnProfile(_ sender: UIButton) {
        let _: ProfileVC = open()
    }
}

extension SlideVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrServiceName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Constants.TableCells.drawerMenuTVC, for: indexPath) as! MenuTVC
        cell.lblService.text = arrServiceName[indexPath.row]
        cell.imgService.image = arrImageService[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewSpotVC") as! ViewSpotVC
            vc.select = .gotoSlideVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
        else if indexPath.row == 1 {
            let _: TermsPoliciesVC = open(){
                $0.type = .TermsCondition
            }
        }
        else if indexPath.row == 2{
            let _: TermsPoliciesVC = open(){
                $0.type = .PrivacyPolicy
            }
        }
        else if indexPath.row == 3{
     
            let _: ReportHelpVC = open()
        }
        else {
            confirmLogoutUser()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func confirmLogoutUser(){
        let alert = UIAlertController(title: Constants.AppStrings.logout, message: Constants.AppStrings.confirmLogout, preferredStyle: .alert)
        
        
        let yesAction = UIAlertAction(title: Constants.AppStrings.yes, style: .default) { (action) in
            self.logoutUser()
        }

        
        let noAction = UIAlertAction(title: Constants.AppStrings.no, style: .cancel) { (action) in
            
        }
        yesAction.titleTextColor = Constants.AppAssets.themeGrey
        noAction.titleTextColor = Constants.AppAssets.themeGrey
        alert.addAction(yesAction)
        alert.addAction(noAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    func logoutUser(){
        do{
            try authVM.auth.signOut()
            AppDefaults.clearAppDefaults()
            let _: LoginVC = open()
        }catch{
            
        }
    }
}
