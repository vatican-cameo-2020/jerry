//
//  HomeMainVC.swift
//  JeeryApp
//
//  Created by daisy on 05/04/21.
//

import UIKit
import KYDrawerController


class HomeMainVC: UIViewController {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var imgViewHome: UIImageViewX!
    @IBOutlet weak var lblInbox: UILabel!
    @IBOutlet weak var btnMessage: UIButtonX!
    @IBOutlet weak var btnInbox: UIButtonX!
    @IBOutlet weak var lblHome: UILabel!
    @IBOutlet weak var btnHome: UIButtonX!
    @IBOutlet weak var imgMarker: UIImageViewX!
    @IBOutlet weak var viewTab: UIViewX!
    @IBOutlet var btnTabs: [UIButtonX]!
    @IBOutlet weak var btnSlide: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var viewContainer: UIView!
    @IBOutlet weak var imgViewInbox: UIImageViewX!
    @IBOutlet weak var btnSearch: UIButton!
    
    var open : Bool = false
    var homeVC : UIViewController!
    var viewVC : UIViewController!
    var messageVC : UIViewController!
    var noChatHomeVc : UIViewController!
    
    var viewControllers : [UIViewController]!
    var selectedIndex : Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnHome.isSelected = true
        imgViewInbox.isHidden = true
        setViewController()
        btnTabsPressed(btnHome)
        btnSearch.isHidden = true
        btnBack.isHidden = true
        NotificationCenter.default.addObserver(self, selector: #selector(btnBackAction), name: Constants.NotifNames.changeNavigation, object: nil)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        NotificationCenter.default.addObserver(self, selector: #selector(tabs), name: Constants.NotifNames.navigateToTabBar, object: nil)
//        if Constants.openDrawer.open == true {
//            if let kyDrawer = self.parent as? KYDrawerController
//            {
//                
//                kyDrawer.setDrawerState(.opened, animated: true)
//                Constants.openDrawer.open = false
//                
//            }
//        }
    }
    
    @IBAction func btnSlide(_ sender: UIButton) {
        if let kyDrawer = self.parent as? KYDrawerController
        {
            
            kyDrawer.setDrawerState(.opened, animated: true)
            
        }
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        NotificationCenter.default.post(name: Constants.NotifNames.navigateBackAction, object: nil)
        
    }
    @IBAction func btnTabsPressed(_ sender: UIButton) {
        
        btnSlide.isHidden = false
        let previousIndex = selectedIndex
        selectedIndex = sender.tag
        Checks(index: sender.tag)
        //Deselect the previous ViewController
        btnTabs[previousIndex].isSelected = false
        let previousVC = viewControllers[previousIndex]
        previousVC.willMove(toParent: nil)
        previousVC.view.removeFromSuperview()
        previousVC.removeFromParent()
        
        sender.isSelected = true
        let vc = viewControllers[selectedIndex]
        lblTitle.text = vc.title
        addChild(vc)
        
        vc.view.frame = viewContainer.bounds
        viewContainer.addSubview(vc.view)
        vc.didMove(toParent: self)
    }
    @objc func tabs(index:Notification){
    let index = index.object as? Int ?? 0
        
        btnTabsPressed(btnTabs[index])
    }
    
    @objc func btnBackAction(notif:Notification){
        let headerTitle = notif.object as! Dictionary<String,Any>
        let isback = headerTitle["isback"] as? Bool  ?? false
        lblTitle.text = headerTitle["title"] as? String ?? ""
        if isback{
            btnBack.isHidden = false
            btnSlide.isHidden = true
            btnSearch.isHidden = true
        }
        else{
            btnBack.isHidden = true
            btnSlide.isHidden = false
            btnSearch.isHidden = true
        }
        
        
        
    }
    
    func setViewController(){
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        homeVC = storyboard.instantiateViewController(withIdentifier: "HomeNavigation") as! UINavigationController
        viewVC = storyboard.instantiateViewController(withIdentifier: "ViewVC") as! ViewVC
        messageVC = storyboard.instantiateViewController(withIdentifier: "AddMessageNavigation") as! UINavigationController
        
        viewControllers = [homeVC,viewVC,messageVC]
        
    }
    func Checks(index : Int){
        if index == 0{
            lblHome.textColor = UIColor(named: "themeYellow")
            imgViewHome.isHidden = false
            imgViewInbox.isHidden = true
            imgMarker.isHidden = false
            lblInbox.textColor = UIColor(named: "themeGrey")
            btnSearch.isHidden = true
            btnBack.isHidden = true
            btnSearch.isHidden = true
        }
        else if index == 1 {
            lblInbox.textColor = UIColor(named: "themeYellow")
            imgViewInbox.isHidden = false
            imgViewHome.isHidden = true
            imgMarker.isHidden = true
            lblHome.textColor = UIColor(named: "themeGrey")
            btnSearch.isHidden = false
            btnBack.isHidden = true
        }
        else{
            lblInbox.textColor = UIColor(named: "themeGrey")
            lblHome.textColor = UIColor(named: "themeGrey")
            imgViewInbox.isHidden = true
            imgViewHome.isHidden = true
            imgMarker.isHidden = false
            btnSearch.isHidden = true
            btnBack.isHidden = true
        }
    }
}
