//
//  tvcUserMessageSend.swift
//  JeeryApp
//
//  Created by daisy on 10/04/21.
//

import UIKit

class tvcUserMessageSend: UITableViewCell {

    @IBOutlet weak var lblUserMessage: UILabel!
    @IBOutlet weak var lblUserDate: UILabel!
    @IBOutlet weak var viewSenderMessage: UIViewX!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        bounds()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func bounds(){
        viewSenderMessage.layer.cornerRadius = 15
        viewSenderMessage.layer.maskedCorners = [.layerMinXMaxYCorner,.layerMaxXMinYCorner,.layerMinXMinYCorner]
    }
    
}
