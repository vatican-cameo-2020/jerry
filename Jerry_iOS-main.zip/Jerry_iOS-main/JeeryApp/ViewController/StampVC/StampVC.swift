//
//  StampVC.swift
//  JeeryApp
//
//  Created by daisy on 05/04/21.
//

import UIKit

class StampVC: BaseViewController{

    //MARK:- Outlets
    @IBOutlet weak var btnPinForMe: UIButton!
    
    //MARK:- Properties
    var messageVM = MessageVM.init()
    
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    //MARK:- Lifecycles
    override func viewWillAppear(_ animated: Bool) {
        
        let dict : Dictionary<String,Any> = ["title":"Stamp","isback":true]
        NotificationCenter.default.post(name: Constants.NotifNames.changeNavigation, object: dict)
        NotificationCenter.default.addObserver(self, selector: #selector(buttonAction), name: Constants.NotifNames.navigateBackAction, object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: Constants.NotifNames.changeNavigation, object: nil)
        NotificationCenter.default.removeObserver(self, name: Constants.NotifNames.navigateBackAction, object: nil)
    }
    
    @objc func buttonAction(){
    
        self.navigationController?.popViewController(animated: true)
    }
  
    @IBAction func btnPinIt(_ sender: UIButtonX) {
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MapViewVC") as! MapViewVC
//        vc.modalPresentationStyle = .overFullScreen
//        self.navigationController?.present(vc, animated: true, completion: nil)
//        vc.pushscreentoview = self
//
        fetchUserData()
    }
    
    func fetchUserData(){
        showProgress()
        messageVM.fetchUserDetails { response in
            self.hideProgress()
            let _: StampMapVC = self.open(){
                $0.justForMe = self.btnPinForMe.isSelected
                $0.messageVM = self.messageVM
            }
        }
    }
    
}
//extension StampVC :  PushScreentoView {
//    func pushScreentoView() {
//        let index : Int = 1
//        NotificationCenter.default.post(name: NSNotification.Name("goToButtonTabs"),object: index)
//        self.navigationController?.popToRootViewController(animated: true)
//    }
//
//}
