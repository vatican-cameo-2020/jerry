//
//  HomeVC.swift
//  JeeryApp
//
//  Created by daisy on 03/04/21.
//

import UIKit

class HomeVC: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var tvHome: DynamicSizeTableView!
    @IBOutlet weak var lblUserTitle: UILabel!
    
    //MARK:- Properties
    var arrImage = [#imageLiteral(resourceName: "ashish'gf.jpeg"),#imageLiteral(resourceName: "dimpal'bf.jpeg"),#imageLiteral(resourceName: "girl.jpeg"),#imageLiteral(resourceName: "model"),#imageLiteral(resourceName: "vishal'gf.jpeg"),#imageLiteral(resourceName: "ashish'gf.jpeg"),#imageLiteral(resourceName: "dimpal'bf.jpeg"),#imageLiteral(resourceName: "girl.jpeg"),#imageLiteral(resourceName: "model"),#imageLiteral(resourceName: "vishal'gf.jpeg")]
    var arrname = ["Diane Tucker","Andrew Moore","Sara Dunn","Laura Barnett","Andrew Moore","Diane Tucker","Andrew Moore","Sara Dunn","Laura Barnett","Andrew Moore"]
    var arrMessage = ["How is your work going?","","Great idea!","How is your job? Is it still OK?","","How is your work going?","","Great idea!","How is your job? Is it still OK?",""]
    var arrDate = ["","","","Nov 7","Nov 10","","","","Nov 7","Nov 10"]
    
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setDelegates()
        lblUserTitle.text = "Hello, \(fetchUserData()?.name ?? "User")"
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        let dict : Dictionary<String,Any> = ["title":"Home","isback":false]
        NotificationCenter.default.post(name: Constants.NotifNames.changeNavigation, object: dict)
    }
    
    //MARK:- Table Delgates
    func setDelegates(){
        let nibName = UINib(nibName: "tvcHomeScreen", bundle:nil)
        self.tvHome.register(nibName, forCellReuseIdentifier: "tvcHomeScreen")
        tvHome.delegate = self
        tvHome.dataSource = self
       
    }
}

//MARK:- Table Delgates
extension HomeVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrname.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tvcHomeScreen", for: indexPath) as! tvcHomeScreen
        cell.imgUser.image = arrImage[indexPath.row]
        cell.lblDate.text = arrDate[indexPath.row]
        cell.lblName.text = arrname[indexPath.row]
        cell.lblMessage.text = arrMessage[indexPath.row]
        if indexPath.row > 2{
            cell.imgMarker.isHidden = true
        }
        else{
            cell.imgMarker.isHidden = false
        }
  
        return cell
    }
}
