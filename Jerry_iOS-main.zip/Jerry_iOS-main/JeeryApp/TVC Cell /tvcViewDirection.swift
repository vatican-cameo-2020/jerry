//
//  tvcViewDirection.swift
//  JeeryApp
//
//  Created by daisy on 03/04/21.
//

import UIKit
import CoreLocation

class tvcViewDirection: UITableViewCell, CLLocationManagerDelegate {

    let  locationManager = CLLocationManager()
    var LocationLatitude : Double = 0
    var LocationLongitutde : Double = 0
    
    @IBOutlet weak var btnDirection: UIButton!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblGroup: UILabel!
    @IBOutlet weak var imgIcon: UIImageViewX!
    override func awakeFromNib() {
        super.awakeFromNib()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    
    }
    @IBAction func btnDirection(_ sender: UIButton) {
        let latitude = LocationLatitude
        let longitude = LocationLongitutde
        let directionsURL = "http://maps.apple.com/?ll=\(latitude),\(longitude)"
        guard let url = URL(string: directionsURL) else {
        return
        }
        if #available(iOS 10.0, *) {
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
        UIApplication.shared.openURL(url)
        }
  
        
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.first
        let latitudes = location?.coordinate.latitude
        let longitudes = location?.coordinate.longitude
        LocationLatitude = latitudes ?? 0
        LocationLongitutde = longitudes ?? 0
        
    }
}
//@IBAction func openMap(_ sender: UIButton?) {
//        let directionsURL = "http://maps.apple.com/?saddr=35.6813023,139.7640529&daddr=35.4657901,139.6201192"
//        guard let url = URL(string: directionsURL) else {
//            return
//        }
//        if #available(iOS 10.0, *) {
//            UIApplication.shared.open(url, options: [:], completionHandler: nil)
//        } else {
//            UIApplication.shared.openURL(url)
//        }
//    }
