//
//  LoginVC.swift
//  JeeryApp
//
//  Created by daisy on 31/03/21.
//

import UIKit
import MaterialTextField
import GoogleSignIn
import AuthenticationServices
import FirebaseAuth


class LoginVC: BaseViewController {

    //MARK:- Outlets
    @IBOutlet weak var btnProceed: UIButtonX!
    @IBOutlet weak var btnForgetPass: UIButton!
    @IBOutlet weak var tfPassword: MFTextField!
    @IBOutlet weak var tfEmail: MFTextField!
    @IBOutlet weak var btnVaildEmail: UIButton!
    @IBOutlet weak var btnRememberMe: UIButton!
    @IBOutlet weak var btnApple: UIButton!
    
    //MARK:- Userdefined Properties
    private let authVM = AuthVM.init()
    let userdefaults = UserDefaults.standard
    var loginForm: LoginForm?
    fileprivate var currentNonce: String?
    
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setDelegates()
        setRememberMe()
        setupSocialLogins()
    }
    
    //MARK:- App UI Setup
    func setDelegates(){
        tfEmail.delegate = self
    }
    
    func setRememberMe(){
        if AppDefaults.rememberMe{
            tfEmail.text = AppDefaults.userEmail
            btnRememberMe.isSelected = true
        }else{
            btnRememberMe.isSelected = false
        }
    }
    
    func setupSocialLogins(){
        GIDSignIn.sharedInstance()?.presentingViewController = self
        GIDSignIn.sharedInstance()?.delegate = self
        if #available(iOS 13.0, *) {
            btnApple.isHidden = false
        } else {
            btnApple.isHidden = true
        }
    }

    //MARK:- Button Actions
    @IBAction func btnProceedAction(_ sender: UIButtonX) {
        removeErrors()
        loginForm = LoginForm(email: (tfEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "").lowercased(), password: tfPassword.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")
        
        if (loginForm?.isValid() ?? false){
            btnVaildEmail.isHidden = false
            removeErrors()
            //authVM.checkUserRegisteredAlready(loginForm!)
            self.checkEmailAvailablity()
        }else{
            processError()
        }
    }
    
    @IBAction func btnForgetPassAction(_ sender: UIButton) {
        
        let _: ForgetPasswordVC = open()
    }
    
    @IBAction func btnTermsAndCndAction(_ sender: UIButton) {
        let _: TermsPoliciesVC = open(){
            $0.type = .TermsCondition
        }
    }
    
    @IBAction func btnShowHidePasswordAction(_ sender: UIButton){
        sender.isSelected = !sender.isSelected
        tfPassword.isSecureTextEntry = !sender.isSelected
    }
    
    @IBAction func btnSocialLoginActions(_ sender: UIButton){
        if sender.tag == 0{
            loginWithGoogle()
        }else if sender.tag == 1{
            loginWithFacebook()
        }else if sender.tag == 2{
            loginWithApple()
        }
    }
    
    @IBAction func tfEmailEditingChanged(_ sender: UITextField) {
        loginForm = LoginForm(email: (tfEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "").lowercased(), password: tfPassword.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")
        if (loginForm?.isValid() ?? false){
            btnVaildEmail.isHidden = false
            removeErrors()
        }else{
            btnVaildEmail.isHidden = true
        }
    }
    
    @IBAction func btnRememberMeAction(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        AppDefaults.rememberMe = sender.isSelected
    }
    
    
    //MARK:- Userdefined Actions
    /// Remove any previous text field errors
    private func removeErrors(){
        tfEmail.setError(nil, animated: true)
    }
    
     ///Check all validations and display errors
    private func processError(){
        let errorReason = loginForm!.errorReason()
        let localizedError = LocalErrors.init().errorWithDescription(errorReason.0)
        switch errorReason.1 {
        case .kEmail:
            tfEmail.setError(localizedError, animated: true)
            break
        default:
            break
        }
    }

    
    //MARK:- Social Logins
    func loginWithFacebook() {
        authVM.loginWithFacebook(fromViewController: self) { (status, creds) in
            if status{
                self.socialLogin(creds!, type: .Facebook)
            }
        }
    }
    
    func loginWithGoogle() {
        GIDSignIn.sharedInstance()?.signIn()
    }
    
    
    func loginWithApple() {
        if #available(iOS 13.0, *) {
            let appleIDProvider = ASAuthorizationAppleIDProvider()
            let request = appleIDProvider.createRequest()
            let nonce = authVM.randomNonceString()
            currentNonce = nonce
            request.requestedScopes = [.fullName, .email]
            request.requestedOperation = .operationImplicit
            request.nonce = authVM.sha256(nonce)
            let authorizationController = ASAuthorizationController(authorizationRequests: [request])
            authorizationController.delegate = self
            authorizationController.presentationContextProvider = self
            authorizationController.performRequests()
        }
    }
    
    //MARK:- Firebase Observer
    
    func checkEmailAvailablity(){
        showProgress()
        authVM.loginForm = self.loginForm ?? LoginForm()
        authVM.checkUserRegisteredAlready() { response in
            if response.statusCode == 200{
                if !(response.userExists){
                    let _: CreateUserPopUpVC = self.customPresent(){
                        $0.delegatePush = self
                        $0.modalTransitionStyle = .crossDissolve
                        $0.modalPresentationStyle = .overFullScreen
                    }
                    self.hideProgress()
                }else{
                    self.loginUser()
                }
            }else{
                self.hideProgress()
                self.toast(response.message)
            }
        }
    }
    
    

    func loginUser(){
        authVM.loginUser { response in
            if response.statusCode == 200{
                self.fetchUserDetails(response.authUser)
            }else{
                self.hideProgress()
                self.toast(response.message)
            }
        }
    }
    
    func fetchUserDetails(_ user: User?){
        authVM.fetchUserDetails(user) { response in
            self.hideProgress()
            if response.statusCode == 200{
                AppDefaults.userLogged = true
                AppDefaults.userEmail = AppDefaults.rememberMe ? (self.tfEmail.text ?? "").lowercased().trimmingCharacters(in: .whitespacesAndNewlines) : ""
                self.navigateToHome()
            }else{
                self.toast(response.message)
            }
        }
    }
    
    func socialLogin(_ authCreds: AuthCredential, type: LoginType){
        showProgress()
        authVM.socialCreds = authCreds
        authVM.loginType = type

        authVM.socialLogin() { response in
            if response.statusCode == 200{
                self.authVM.loginForm = LoginForm(email: response.signupForm.email)
                self.authVM.checkUserRegisteredAlready() { resp in
                    if resp.statusCode == 200{
                        if !(resp.userExists){
                            self.addloggedUser(response)
                        }else{
                            
                            self.fetchUserDetails(response.authUser)
                        }
                    }else{
                        self.hideProgress()
                        self.toast(resp.message)
                    }
                }
                self.hideProgress()
                
            }else{
                self.toast(response.message)
                self.hideProgress()
            }
        }
    }
    
    func addloggedUser(_ resp: AuthResponse){
        authVM.addUser(resp.signupForm, user: resp.authUser!) { response in
            self.hideProgress()
            if response.statusCode == 200{
                AppDefaults.userLogged = true
                AppDefaults.userEmail = AppDefaults.rememberMe ? (self.tfEmail.text ?? "").lowercased().trimmingCharacters(in: .whitespacesAndNewlines) : ""
//                self.navigateToHome()
                if AppDefaults.isFirstRun(){
                    let _: PremissionVC = self.customPresent(){
                        $0.navigateDelegate = self
                        $0.modalTransitionStyle = .crossDissolve
                    }
                }else{
                    let _: AddSpotVC = self.open(){
                        $0.fromRegisteration = true
                    }
                }
            }else{
                self.toast(response.message)
            }
        }
    }
}

//MARK:- PushScreen Delegate
extension LoginVC : PermissionDelegate {
    func allowPermission() {
        let _: AddSpotVC = open(){
            $0.fromRegisteration = true
        }
    }
}

extension LoginVC: UITextFieldDelegate{
    func textFieldDidEndEditing(_ textField: UITextField) {
        loginForm = LoginForm(email: (tfEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "").lowercased(), password: tfPassword.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")
        if (loginForm?.isValid() ?? false){
            btnVaildEmail.isHidden = false
            removeErrors()
        }else{
            btnVaildEmail.isHidden = true
            processError()
        }
    }
}
    
extension LoginVC : PushScreen{
    func pushScreen() {
        let _: CreateAcoountVC = open()
    }
}

// MARK: - GIDSignInDelegate
extension LoginVC: GIDSignInDelegate {
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            if (error as NSError).code == GIDSignInErrorCode.hasNoAuthInKeychain.rawValue {
                print("The user has not signed in before or they have since signed out.")
            } else {
                print("\(error.localizedDescription)")
            }
            return
        }
        
        guard let authentication = user.authentication else { return }
        let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken,
                                                          accessToken: authentication.accessToken)
        self.socialLogin(credential, type: .Google)

    }
}

//MARK:- Apple Login Delegates
extension LoginVC: ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding{
    
    @available(iOS 13.0, *)
    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        self.showAlert(error.localizedDescription)
    }
    
    @available(iOS 13.0, *)
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        return self.view.window!
    }
    
    @available(iOS 13.0, *)
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        if let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential {
            
            let idToken = appleIDCredential.identityToken ?? Data()
            
            guard let nonce = self.currentNonce else {
                return
            }
            
            guard let idTokenString = String(data: idToken, encoding: .utf8) else {
                return
            }
            
            // Initialize a Firebase credential.
            let credential = OAuthProvider.credential(withProviderID: "apple.com",
                                                      idToken: idTokenString,
                                                      rawNonce: nonce)
            let userName = (appleIDCredential.fullName?.givenName ?? "") + " " + (appleIDCredential.fullName?.familyName ?? "")
            self.authVM.appleDisplayName = userName
            self.socialLogin(credential, type: .Apple)
        
            
           // let req = AuthRequest(email: email, firstName: firstName, lastName: lastName, providerId: user, socialToken: idTokenString)
//            self.authVM.socialLogin(req)
        }
    }
}
