//
//  CustomProgressView.swift
//  EverArk
//
//  Created by Sachtech on 21/10/20.
//  Copyright © 2020 SachTech. All rights reserved.
//

import UIKit

class CustomProgressView: UIView {
    
    @IBOutlet var vwContainer: UIView!
    @IBOutlet weak var vwSpinner: UIView!
    @IBOutlet weak var lblText: UILabel!
    
    override init(frame: CGRect) {
       super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        commonInit()
    }
    
    private func commonInit(){
        Bundle.main.loadNibNamed("CustomProgressView", owner: self, options: nil)
        addSubview(vwContainer)
        vwContainer.frame = self.bounds
        vwContainer.autoresizingMask = [.flexibleWidth, .flexibleHeight]
    }
    
    func setLoader(_ text: String){
        setUpAnimation(in: vwSpinner.layer, size: vwSpinner.frame.size)
        lblText.text = text
    }
    
     private func setUpAnimation(in layer: CALayer, size: CGSize) {
        let duration: CFTimeInterval = 1.0
        
        //    Scale animation
        // Rotate animation
        let rotateAnimation = CAKeyframeAnimation(keyPath: "transform.rotation.z")
        rotateAnimation.keyTimes = [0, 0.5, 1]
        rotateAnimation.values = [0, Double.pi, 2 * Double.pi]
        
        // Animation
        let animation = CAAnimationGroup()
        
        animation.animations = [rotateAnimation]
        animation.timingFunction = CAMediaTimingFunction(name: .linear)
        animation.duration = duration
        animation.repeatCount = HUGE
        animation.isRemovedOnCompletion = false
        
        // Draw circle
        let circle = layerWidth(size: CGSize(width: size.width, height: size.height))
        
        //            layerWith(size: CGSize(width: size.width, height: size.height), color: color)
        let frame = CGRect(x: (layer.bounds.size.width - size.width) / 2,
                           y: (layer.bounds.size.height - size.height) / 2,
                           width: size.width,
                           height: size.height)
        
        circle.frame = frame
        circle.add(animation, forKey: "animation")
        layer.addSublayer(circle)
    }
    
    
    private func layerWidth(size: CGSize) -> CALayer
    {
        let layer: CAShapeLayer = CAShapeLayer()
        let path: UIBezierPath = UIBezierPath()
        let path2: UIBezierPath = UIBezierPath()
        let layer2: CAShapeLayer = CAShapeLayer()
        
        
        path.addArc(withCenter: CGPoint(x: size.width / 2, y: size.height / 2),
                    radius: size.width / 2,
                    startAngle: CGFloat(-3.5 * Double.pi / 4),
                    endAngle: CGFloat(-Double.pi / 4),
                    clockwise: false)
        path2.addArc(withCenter: CGPoint(x: size.width / 2, y: size.height / 2),
                     radius: size.width / 2,
                     startAngle: CGFloat(0),
                     endAngle: CGFloat(Double.pi),
                     clockwise: false)

        layer.fillColor = nil
        //        layer.
        layer.strokeColor = Constants.AppAssets.cellBackground.cgColor//UIColor(named: "theme")?.cgColor
        layer.lineWidth = 5
        layer2.fillColor = nil
        layer2.strokeColor = Constants.AppAssets.themeGrey.cgColor//UIColor(named: "senderClr")?.cgColor
        layer2.lineWidth = 5
        layer.lineCap = .round
        layer2.lineCap = .round
        
        layer.backgroundColor = nil
        layer.path = path2.cgPath
        layer.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        
        layer2.backgroundColor = nil
        layer2.path = path.cgPath
        layer2.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        layer.addSublayer(layer2)
        return layer
    }
}
