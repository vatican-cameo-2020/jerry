//
//  tvcLocationList.swift
//  JeeryApp
//
//  Created by daisy on 14/04/21.
//

import UIKit

class tvcLocationList: UITableViewCell {

    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblLocationMark: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
      
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
}
