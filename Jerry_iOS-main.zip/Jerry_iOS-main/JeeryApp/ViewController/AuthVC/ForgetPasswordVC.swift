//
//  ForgetPasswordVC.swift
//  JeeryApp
//
//  Created by daisy on 01/04/21.
//

import UIKit
import MaterialTextField
import FirebaseAuth

class ForgetPasswordVC: BaseViewController {

    //MARK:- Outlets
    @IBOutlet weak var btnSendLink: UIButtonX!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var tfEmail: MFTextField!
    
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        tfEmail.delegate = self
    }
    
    func resetPassword(){
        let email = (tfEmail.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        if email.isEmpty{
            tfEmail.setError(LocalErrors.init().errorWithDescription(Constants.AppStrings.emptyEmail), animated: true)
        }
        else if !email.isValidEmail{
            tfEmail.setError(LocalErrors.init().errorWithDescription(Constants.AppStrings.notValidEmail), animated: true)
        }else{
            showProgress()
            Auth.auth().sendPasswordReset(withEmail: email) { error in
                self.hideProgress()
                if error == nil{
                    self.tfEmail.text = ""
                    self.showAlert(Constants.AppStrings.resetEmailPassword)
                    
                }else{
                    self.tfEmail.setError(error, animated: true)
                }
            }
        }
    }
    
    //MARK:- Button Actions
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCancel(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
   
    @IBAction func btnSendLink(_ sender: UIButtonX) {
        resetPassword()
    }
}

extension ForgetPasswordVC: UITextFieldDelegate{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        tfEmail.setError(nil, animated: true)
    }
}
