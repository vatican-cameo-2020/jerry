//
//  tvcSwipeUp.swift
//  JeeryApp
//
//  Created by daisy on 13/04/21.
//

import UIKit

class tvcSwipeUp: UITableViewCell {

    @IBOutlet weak var lblLocationName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
