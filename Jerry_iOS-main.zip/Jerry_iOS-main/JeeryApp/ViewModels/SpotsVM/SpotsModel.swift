//
//  SpotsModel.swift
//  JeeryApp
//
//  Created by Kapil on 27/04/21.
//

import Foundation

struct SpotsResponse: JsonDeserilizer {
    var statusCode: Int = 0
    var spotRespType: SpotAction = .Get_Spots
    var message: String = ""
    
    mutating func deserilize(values: Dictionary<String, Any>?) {
        
    }
}

struct SpotDetail: JsonSerilizer, JsonDeserilizer {
    
    var statusCode: Int = 0
    var spotId: String = ""
    var spotName: String = ""
    var street: String = ""
    var city: String = ""
    var state: String = ""
    var zip: String = ""
    var latitude: String = ""
    var longitude: String = ""
    var address: String = ""

    func serilize() -> Dictionary<String, Any> {
        
        var addressArr = [street, city, state, zip]
        addressArr.removeAll(where: {$0.isEmpty})
        let address = addressArr.joined(separator: ", ")
        
        return [
            FirebaseFieldKeys.Spots.spotId: spotId,
            FirebaseFieldKeys.Spots.spotName: spotName,
            FirebaseFieldKeys.Spots.street: street,
            FirebaseFieldKeys.Spots.city: city,
            FirebaseFieldKeys.Spots.state: state,
            FirebaseFieldKeys.Spots.zip: zip,
            FirebaseFieldKeys.Spots.address: address,
            FirebaseFieldKeys.Spots.latitude: latitude,
            FirebaseFieldKeys.Spots.longitude: longitude
        ]
    }
    
    mutating func deserilize(values: Dictionary<String, Any>?) {
        spotId = values?[FirebaseFieldKeys.Spots.spotId] as? String ?? ""
        spotName = values?[FirebaseFieldKeys.Spots.spotName] as? String ?? ""
        street = values?[FirebaseFieldKeys.Spots.street] as? String ?? ""
        city = values?[FirebaseFieldKeys.Spots.city] as? String ?? ""
        state = values?[FirebaseFieldKeys.Spots.state] as? String ?? ""
        zip = values?[FirebaseFieldKeys.Spots.zip] as? String ?? ""
        address = values?[FirebaseFieldKeys.Spots.address] as? String ?? ""
        latitude = values?[FirebaseFieldKeys.Spots.latitude] as? String ?? ""
        longitude = values?[FirebaseFieldKeys.Spots.longitude] as? String ?? ""
    }
    
    
    func isValid() -> Bool {
        return !spotName.isEmpty && !street.isEmpty && !city.isEmpty && !state.isEmpty && !zip.isEmpty
    }

    func errorReason() -> (String, ValidatorKeys) {
        if spotName.isEmpty{
            return (Constants.AppStrings.emptySpotName,ValidatorKeys.kSpotName)
        }
        else if street.isEmpty{
            return (Constants.AppStrings.emptyStreet,ValidatorKeys.kStreet)
        }
        else if city.isEmpty{
            return (Constants.AppStrings.emptyCity,ValidatorKeys.kCity)
        }
        else if state.isEmpty{
            return (Constants.AppStrings.emptyState,ValidatorKeys.kState)
        }
        else if zip.isEmpty{
            return (Constants.AppStrings.emptyZip,ValidatorKeys.kZip)
        }
        else{
            return (Constants.AppStrings.unknownError,ValidatorKeys.kUnknown)
        }
    }
}
