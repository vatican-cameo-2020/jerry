//
//  AppDelegate.swift
//  JeeryApp
//
//  Created by daisy on 31/03/21.
//

import UIKit
import IQKeyboardManagerSwift
import FBSDKCoreKit
import GoogleSignIn
import Firebase


@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    
//    var callObserver: CXCallObserver!
    
    class func share() -> AppDelegate{
        return UIApplication.shared.delegate as! AppDelegate
    }
//    let firestoreRef = Firestore.firestore()
//    let storageRef = Storage.storage().reference()
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        FirebaseApp.configure()
        IQKeyboardManager.shared.enable = true
        GIDSignIn.sharedInstance().clientID = Constants.SocialKeys.googleClientId
        ApplicationDelegate.shared.application(application, didFinishLaunchingWithOptions: launchOptions)
        
//
//        callObserver = CXCallObserver()
//        callObserver.setDelegate(self, queue: nil) // nil queue means main thread
        return true
    }
    
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {

        return ApplicationDelegate.shared.application(
            application,
            open: url,
            sourceApplication: sourceApplication,
            annotation: annotation
        )
    }
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any]) -> Bool {
        
        return GIDSignIn.sharedInstance().handle(url)
    }

    // MARK: UISceneSession Lifecycle

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
}

//extension AppDelegate: CXCallObserverDelegate {
//    func callObserver(_ callObserver: CXCallObserver, callChanged call: CXCall) {
//        if call.hasEnded == true {
//            print("Disconnected")
//        }
//
//        if call.isOutgoing == true && call.hasConnected == false {
//            print("Dialing")
//
//        }
//        if call.isOutgoing == false && call.hasConnected == false && call.hasEnded == false {
//            print("Incoming")
//        }
//
//        if call.hasConnected == true && call.hasEnded == false {
//            print("Connected")
//        }
//    }
//}
