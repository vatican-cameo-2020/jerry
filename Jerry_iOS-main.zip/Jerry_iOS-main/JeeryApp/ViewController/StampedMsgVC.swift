//
//  StampedMsgVC.swift
//  JeeryApp
//
//  Created by daisy on 15/04/21.
//

import UIKit

class StampedMsgVC: UIViewController {

    var arrUserMsg = ["I am on my way, let’s get drunk"]
    var arrReceiverMsg = ["I am on my way, let’s get drunk"]
    var arrReceiverTime = ["Nov 4, 18:03"]
    var arrSendTime = ["Nov 4, 18:03"]
    
    @IBOutlet weak var tvStampedChat: DynamicSizeTableView!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var imgUser: UIImageViewX!
    @IBOutlet weak var btnBack: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        tvStampedChat.delegate = self
        tvStampedChat.dataSource = self
    }

    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}
extension StampedMsgVC : UITableViewDelegate,UITableViewDataSource{

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "tvcMap", for: indexPath) as! tvcMap
            return cell
        }
        else if indexPath.row == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tvcUserStampedMsg", for: indexPath) as! tvcUserStampedMsg
            cell.lblUserMsg.text = "I am on my way, let’s get drunk"
            cell.lblDate.text = "Nov 4, 18:03"
            return cell
        }
        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tvcReceiverStampedMsg", for: indexPath) as! tvcReceiverStampedMsg
            cell.lblMsg.text = "I am on my way, let’s get drunk"
            cell.lblTime.text = "Nov 4, 18:03"
            return cell
        }
    }
    
    
}
