//
//  AddSpotVC.swift
//  JeeryApp
//
//  Created by daisy on 02/04/21.
//

import UIKit
import KYDrawerController
import MaterialTextField
import CoreLocation

class AddSpotVC: BaseViewController {

    //MARK:- Outlets
    @IBOutlet weak var tfSearchLocation: MFTextField!
    @IBOutlet weak var btnSetLocation: UIButton!
    @IBOutlet weak var tvLocationList: DynamicSizeTableView!
    @IBOutlet weak var viewLocation: UIView!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var viewStack: UIStackView!
    @IBOutlet weak var tfNameLocation: MFTextField!
    @IBOutlet weak var tfStreet: MFTextField!
    @IBOutlet weak var tfCity: MFTextField!
    @IBOutlet weak var tfState: MFTextField!
    @IBOutlet weak var tfZip: MFTextField!
    @IBOutlet var btnValidSign: [UIButton]!
    
    @IBOutlet var textFieldsCollection: [MFTextField]!
    
    var spotsVM: SpotsVM = SpotsVM.init()
    var spotForm: SpotDetail = SpotDetail()
    var locations: [String] = []
    var fromEditing: Bool = false
    var fromRegisteration: Bool =  false
        
    override func viewDidLoad() {
        super.viewDidLoad()
        setDelegate()
        viewLocation.isHidden = true
     //   observeSpotResponse()
        btnBack.isHidden = fromRegisteration
        setSpotData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    //MARK:- Userdefined Actions
    
    func setDelegate(){
        let nibName = UINib(nibName: "tvcLocationList", bundle:nil)
        self.tvLocationList.register(nibName, forCellReuseIdentifier: "tvcLocationList")
        tvLocationList.delegate = self
        tvLocationList.dataSource = self
        tfSearchLocation.delegate = self
        tfNameLocation.delegate = self
        tfStreet.delegate = self
        tfCity.delegate = self
        tfZip.delegate = self
        tfState.delegate = self

    }
    
    func setSpotData(){
        tfNameLocation.text = spotForm.spotName
        tfStreet.text = spotForm.street
        tfState.text = spotForm.state
        tfCity.text = spotForm.city
        tfZip.text = spotForm.zip
        
    }
    
    fileprivate func setupForm() {
        spotForm = SpotDetail(spotId: spotForm.spotId, spotName: tfNameLocation.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "", street: tfStreet.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "", city: tfCity.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "", state: tfState.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "", zip: tfZip.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "", latitude: spotForm.latitude, longitude: spotForm.longitude)
        if locations.count == 2{
            spotForm.latitude = locations[0]
            spotForm.longitude = locations[1]
        }
    }
    
    private func removeErrors(){
        tfNameLocation.setError(nil, animated: true)
        tfStreet.setError(nil, animated: true)
        tfCity.setError(nil, animated: true)
        tfState.setError(nil, animated: true)
        tfZip.setError(nil, animated: true)
    }
    
     ///Check all validations and display errors
    private func processError(){
        let errorReason = spotForm.errorReason()
        let localizedError = LocalErrors.init().errorWithDescription(errorReason.0)
        switch errorReason.1 {
        case .kSpotName:
            tfNameLocation.setError(localizedError, animated: true)
            break
        case .kStreet:
            tfStreet.setError(localizedError, animated: true)
            break
        case .kCity:
            tfCity.setError(localizedError, animated: true)
            break
        case .kState:
            tfState.setError(localizedError, animated: true)
            break
        case .kZip:
            tfZip.setError(localizedError, animated: true)
            break
        default:
            break
        }
    }
    
    
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSetLocation(_ sender: UIButton) {
        let _: AddressMapVC = open(){
            $0.mapDelegate = self
        }
    }
    
    @IBAction func btnConfirm(_ sender: UIButtonX) {
        setupForm()
        removeErrors()
        if spotForm.isValid(){
            fromEditing ? self.updateSpotToDatabase() : self.addSpotToDatabase()
        }else{
            processError()
        }
        
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewSpotVC") as! ViewSpotVC
//        vc.select = .gotoViewSpot
//        self.navigationController?.pushViewController(vc, animated: true)
    }

    
    @IBAction func editingChanged(_ sender: MFTextField) {
        btnValidSign[sender.tag].isHidden = sender.text?.isEmpty ?? true
        sender.setError(nil, animated: true)
    }
    
    @IBAction func btnPickLocation(_ sender: UIButton) {
        
    }
    
    //MARK:- Firebase Observer
    func observeSpotResponse(){

//        spotsVM.isLoading.subscribe { (isLoading) in
//            isLoading ? self.showProgress() : self.hideProgress()
//        }.disposed(by: spotsVM.disposeBag)
//
//        spotsVM.response.subscribe { (response) in
//            if response?.spotRespType == .Add_Spot && response?.statusCode == 200{
//                let _: ViewSpotVC = self.open(){
//                    $0.select = .gotoViewSpot
//                }
//            }
//        } onError: { (error) in
//            self.toast(error.localizedDescription)
//        }.disposed(by: spotsVM.disposeBag)
    }
    func addSpotToDatabase(){
        showProgress()
      
        spotsVM.addSpot(spotForm) { (response) in
            self.hideProgress()
            if response.statusCode == 200{
                let _: ViewSpotVC = self.open()
                self.resetFields()
                
            }else{
                self.toast(response.message)
            }
        }
    }
    
    func updateSpotToDatabase(){
        showProgress()
        spotsVM.updateSpot(spotForm) { (response) in
            self.hideProgress()
            if response.statusCode == 200{
                let _: ViewSpotVC = self.open()
                self.resetFields()
            }else{
                self.toast(response.message)
            }
        }
    }
    
    func resetFields(){
        tfSearchLocation.text = ""
        tfNameLocation.text = ""
        tfStreet.text = ""
        tfZip.text = ""
        tfCity.text = ""
        tfState.text = ""
    }
}

extension AddSpotVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0 //arrAddress.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tvcLocationList", for: indexPath) as! tvcLocationList
//        cell.lblLocationMark.text = arrLocationMark[indexPath.row]
//        cell.lblAddress.text = arrAddress[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddressMapVC") as! AddressMapVC
//        vc.select = .GotoViewSpot
//        self.navigationController?.pushViewController(vc, animated: true)
    }
    

}

extension AddSpotVC: MapViewDelegate{
    func onLocationFetched(_ location: LocationAddress) {
        tfStreet.text = location.street
        tfState.text = location.state
        tfCity.text = location.city
        tfZip.text = location.pincode
        self.locations = [location.latitude, location.longitude]
        self.tfSearchLocation.text = location.address
        self.tfSearchLocation.resignFirstResponder()
        setValidation()
    }
    
    func setValidation(){
        for tf in textFieldsCollection{
            btnValidSign[tf.tag].isHidden = tf.text?.isEmpty ?? true
        }
    }
}

extension AddSpotVC: UITextFieldDelegate{
    func textFieldDidEndEditing(_ textField: UITextField) {
        btnValidSign[textField.tag].isHidden = textField.text?.isEmpty ?? true
        
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        viewLocation.isHidden = false
    }
}
