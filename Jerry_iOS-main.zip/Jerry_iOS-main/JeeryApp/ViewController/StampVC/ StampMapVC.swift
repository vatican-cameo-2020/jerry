//
//  MapViewVC.swift
//  JeeryApp
//
//  Created by daisy on 06/04/21.
//

import UIKit
import MapKit
import CoreLocation
import MaterialTextField

class StampMapVC: BaseViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var imgPin: UIImageViewX!
    @IBOutlet weak var tfLocationName: MFTextField!
    
    //MARK:- Properties
    var messageVM = MessageVM.init()
    let locationManager = CLLocationManager()
    var justForMe: Bool = false
    var locationCoordinates: CLLocationCoordinate2D?
  
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set initial location in Honolulu
     
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    //MARK:- Button Actions
    @IBAction func btnBack(_ sender: UIButton) {
     //   self.dismiss(animated: true, completion: nil)
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnConfirm(_ sender: UIButtonX) {
        if (tfLocationName.text?.isEmpty ?? false){
            self.toast(Constants.AppStrings.selectLocationName)
        }else{
            justForMe ? stampJustForMe() : nil
        }
    }

    //MARK:- Userdefined Functions
    func stampJustForMe(){
        showProgress()
        messageVM.stampLocationForMe { response in
            self.hideProgress()
            if response.statusCode == 200{
                self.goToInbox()
            }else{
                self.toast(response.message)
            }
        }
    }
    
    func stampLocationToFriends(){
        
    }
    
    
    func goToInbox(){
        let index : Int = 1
        NotificationCenter.default.post(name: Constants.NotifNames.navigateToTabBar,object: index)
        self.navigationController?.popToRootViewController(animated: true)
    }

}

//MARK:- Location Delegates
extension StampMapVC: CLLocationManagerDelegate{
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            manager.stopUpdatingLocation()
            setLocationOnMap(location)
        }
    }
    
    func setLocationOnMap(_ location : CLLocation){
        let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
        mapView.setRegion(region, animated: true)
    }
}

