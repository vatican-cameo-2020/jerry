//
//  MessageVC.swift
//  JeeryApp
//
//  Created by daisy on 05/04/21.
//

import UIKit

class MessageVC: BaseViewController {

    @IBOutlet weak var btnStamp: UIButtonX!
    @IBOutlet weak var btnMessages: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        let dict : Dictionary<String,Any> = ["title":"Message","isback":false]
        NotificationCenter.default.post(name: Constants.NotifNames.changeNavigation, object: dict)
    }
    
    @IBAction func btnStamp(_ sender: UIButtonX) {
        let _: StampVC = open()
    }
    
    @IBAction func btnMessage(_ sender: UIButtonX) {
        let _: SendMessageVC = open()
    }
}
