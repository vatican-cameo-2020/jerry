//
//  ReportandHelpVC.swift
//  JeeryApp
//
//  Created by daisy on 05/04/21.
//

import UIKit

class ReportHelpVC: BaseViewController {

    //MARK:- Outlets
    @IBOutlet weak var textviewBox: UITextView!
    var authVM = AuthVM.init()
    
    
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        textviewBox.layer.cornerRadius = 10
    }
    
    //MARK:- Button Actions
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnSendAction(_ sender: UIButton) {
        if !textviewBox.text.isEmpty{
            authVM.reportIssue(textviewBox.text) { response in
                if response.statusCode == 200{
                    self.textviewBox.text = ""
                    self.toast(Constants.AppStrings.reviewSubmitSuccess)
                }else{
                    self.toast(response.message)
                }
            }
        }else{
            self.toast(Constants.AppStrings.emptyIssue)
        }
    }
}
