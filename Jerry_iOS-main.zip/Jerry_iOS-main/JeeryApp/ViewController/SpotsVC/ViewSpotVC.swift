//
//  ViewSpotVC.swift
//  JeeryApp
//
//  Created by daisy on 02/04/21.
//

import UIKit

enum back{
    case gotoViewSpot
    case gotoSlideVC
}

class ViewSpotVC: BaseViewController {

    //MARK:- Outlets
    @IBOutlet weak var tblAddedSpot: UITableView!
    @IBOutlet weak var btnConfirm: UIButtonX!
    
    var spotsVM: SpotsVM = SpotsVM.init()
    var select = back.gotoViewSpot
    var arrSpotname = ["Home","Gym","Office","Guest House","Park"]
   
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setDelegates()
//        observeSpotResponse()
//        spotsVM.fetchUserSpots()
        
        btnConfirm.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        fetchUserSpots()
    }
    
    // Tableview Delegate
    func setDelegates(){
        let nibName = UINib(nibName: Constants.TableCells.spotTVC, bundle:nil)
        self.tblAddedSpot.register(nibName, forCellReuseIdentifier: Constants.TableCells.spotTVC)
        tblAddedSpot.delegate = self
        tblAddedSpot.dataSource = self
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        switch select {
        case .gotoViewSpot :
            self.navigationController?.popViewController(animated: true)
        case .gotoSlideVC :
            let story = UIStoryboard(name: "Main", bundle:nil)
            let vc = story.instantiateViewController(withIdentifier: "drawerNavigation") as! UINavigationController
            UIApplication.shared.windows.first?.rootViewController = vc
            UIApplication.shared.windows.first?.makeKeyAndVisible()
           // Constants.openDrawer.open = true
        }
    }
    
    @IBAction func btnConfirm(_ sender: UIButtonX) {
        navigateToHome()
    }
    
    @IBAction func btnAddSpot(_ sender: UIButtonX) {
//        switch select {
//        case .gotoViewSpot :
//            self.navigationController?.popViewController(animated: true)
//        case .gotoSlideVC :
//            let _: AddSpotVC = open()
//        }
        
        let _: AddSpotVC = open(){
            $0.fromRegisteration = false
        }
    }
    
    
    //  Cell Btn Add Target
    
    @IBAction func editSpot(_ sender: UIButton){
//        switch select {
//        case .gotoViewSpot :
//            self.navigationController?.popViewController(animated: true)
//        case .gotoSlideVC :
//
//        }
        let _: AddSpotVC = open(){
            $0.fromRegisteration = false
            $0.fromEditing = true
            $0.spotForm = self.spotsVM.spots[sender.tag]
        }
    }

    
    //MARK:- Firebase Observer
    func fetchUserSpots(){
        
//        spotsVM.isLoading.subscribe { (isLoading) in
//            isLoading ? self.showProgress() : self.hideProgress()
//        }.disposed(by: spotsVM.disposeBag)
//
//        spotsVM.response.subscribe { (response) in
//            if response?.spotRespType == .Get_Spots && response?.statusCode == 200{
//                self.tblAddedSpot.reloadData()
//            }
//        } onError: { (error) in
//            self.toast(error.localizedDescription)
//        }.disposed(by: spotsVM.disposeBag)
        showProgress()
        spotsVM.fetchUserSpots { response in
            self.hideProgress()
            if response.statusCode == 200{
                self.btnConfirm.isHidden = self.spotsVM.spots.isEmpty
                self.tblAddedSpot.reloadData()
            }else{
                self.btnConfirm.isHidden = true
                self.toast(response.message)
            }
        }
    }

}
// Extension of tableview delegate

extension ViewSpotVC :UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.spotsVM.spots.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: Constants.TableCells.spotTVC, for: indexPath) as! SpotsTVC
        cell.lblSpotName.text = self.spotsVM.spots[indexPath.row].spotName
        cell.btnEdit.tag = indexPath.row
        cell.btnEdit.addTarget(self, action: #selector(editSpot(_:)), for: .touchUpInside)
        return cell
    }
    
    
}
