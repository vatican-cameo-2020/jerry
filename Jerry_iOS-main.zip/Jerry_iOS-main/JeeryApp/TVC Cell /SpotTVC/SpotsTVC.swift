//
//  tvcAddedSpot.swift
//  JeeryApp
//
//  Created by daisy on 02/04/21.
//

import UIKit

class SpotsTVC: UITableViewCell {

    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var lblSpotName: UILabelX!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnEdit(_ sender: UIButton) {
    }
}
