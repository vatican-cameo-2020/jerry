//
//  OtpVerificationVC.swift
//  JeeryApp
//
//  Created by daisy on 01/04/21.
//

import UIKit
import OTPFieldView
import FirebaseAuth

class OtpVerificationVC: BaseViewController, UITextFieldDelegate {
    
    //MARK:- Outlets
    @IBOutlet weak var btnVerify: UIButtonX!
    @IBOutlet weak var viewOTP: OTPFieldView!
    
    //MARK:- Properties
    var authVM: AuthVM = AuthVM.init()
    var verificationCode: String = ""
    var filledOTP: String = ""
    
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setupOtpView()
    }
    
    func setupOtpView(){
        self.viewOTP.fieldsCount = 5
        self.viewOTP.fieldBorderWidth = 2
        self.viewOTP.defaultBorderColor = UIColor.init(named: "themeGrey") ?? UIColor.black
        self.viewOTP.filledBorderColor = UIColor.init(named: "themeGrey") ?? UIColor.black
        self.viewOTP.cursorColor = UIColor.init(named: "themeGrey") ?? UIColor.black
        self.viewOTP.displayType = .underlinedBottom
        self.viewOTP.fieldSize = 40
        self.viewOTP.separatorSpace = 8
        self.viewOTP.shouldAllowIntermediateEditing = false
        self.viewOTP.delegate = self
        self.viewOTP.initializeUI()
    }
    
    func verifyPhoneNumber(){
        showProgress()
        HitApi.share().verifyOTP(view: self.view, phoneNumber: authVM.registerForm.phone, otp: filledOTP) { status, dict in
            self.hideProgress()
            if status{
                self.registerUser()
            }
        }
    }
    
    func registerUser(){
        showProgress()
        authVM.registerUser(authVM.registerForm) { (response) in
            if response.statusCode == 200{
                self.addloggedUser(response)
            }else{
                self.toast(response.message)
                self.hideProgress()
            }
        }
    }
    
    func addloggedUser(_ resp: AuthResponse){
        authVM.addUser(resp.signupForm, user: resp.authUser!) { response in
            self.hideProgress()
            if response.statusCode == 200{
                AppDefaults.userLogged = true
                AppDefaults.userEmail = AppDefaults.rememberMe ? self.authVM.registerForm.email : ""
                // self.navigateToHome()
                if AppDefaults.isFirstRun(){
                    let _: PremissionVC = self.customPresent(){
                        $0.navigateDelegate = self
                        $0.modalTransitionStyle = .crossDissolve
                    }
                }else{
                    let _: AddSpotVC = self.open(){
                        $0.fromRegisteration = true
                    }
                }
            }else{
                self.toast(response.message)
            }
        }
    }
    
    func sendRegistrationOTP(){
      showProgress()
        HitApi.share().sendOTP(view: self.view, phoneNumber: self.authVM.registerForm.phone) { (status, message) in
            self.hideProgress()
            self.toast(message)
        }
    }
    
    @IBAction func btnVerify(_ sender: UIButtonX) {
//        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ResetPasswordVC") as! ResetPasswordVC
//        self.navigationController?.pushViewController(vc, animated: true)
        self.verifyPhoneNumber()
         //registerUser()
    }
    
    @IBAction func btnBackAction(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnResendAction(_ sender: UIButton) {
        
    }
}

//MARK:- OTP Verfication
extension OtpVerificationVC: OTPFieldViewDelegate {
    func hasEnteredAllOTP(hasEnteredAll hasEntered: Bool) -> Bool {
        print("Has entered all OTP? \(hasEntered)")
        return false
    }
    
    func shouldBecomeFirstResponderForOTP(otpTextFieldIndex index: Int) -> Bool {
        return true
    }
    
    func enteredOTP(otp otpString: String) {
       
        print("OTPString: \(otpString)")
        filledOTP = otpString
        self.verifyPhoneNumber()
    }
}
//MARK:- PushScreen Delegate
extension OtpVerificationVC : PermissionDelegate {
    func allowPermission() {
        let _: AddSpotVC = open(){
            $0.fromRegisteration = true
        }
    }
}
