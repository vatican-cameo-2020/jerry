//
//  ChatViewVC.swift
//  JeeryApp
//
//  Created by daisy on 08/04/21.
//

import UIKit

class ChatViewVC: UIViewController {

    @IBOutlet weak var btnSend: UIButtonX!
    @IBOutlet weak var viewMessageField: UIViewX!
    @IBOutlet weak var viewSwipe: UIViewX!
    @IBOutlet weak var imgSend: UIImageView!

    @IBOutlet weak var lblAlert: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnSend.isHidden = true
        viewMessageField.isHidden = true
        imgSend.isHidden = true
        let swipeleft = UISwipeGestureRecognizer(target: self, action: #selector(swipeGesture))
        let swiperight = UISwipeGestureRecognizer(target: self, action: #selector(swipeGesture))
        swiperight.direction = .right
        swipeleft.direction = .left
        viewSwipe.addGestureRecognizer(swiperight)
        viewSwipe.addGestureRecognizer(swipeleft)
        viewSwipe.layer.cornerRadius = 15
        viewSwipe.layer.shadowRadius = 15
        viewSwipe.layer.maskedCorners = [.layerMaxXMaxYCorner,.layerMaxXMinYCorner,.layerMinXMinYCorner]
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @objc func swipeGesture(){
        viewSwipe.isHidden = true

        lblAlert.isHidden = true
        bounds()
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MultipleTypeChatVC") as! MultipleTypeChatVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func bounds(){
        imgSend.layer.cornerRadius = 15
        imgSend.layer.shadowRadius = 15
        imgSend.layer.shadowOpacity = 6
        imgSend.layer.shadowColor = UIColor.init(named: "themeBlack")?.cgColor
        imgSend.layer.maskedCorners = [.layerMaxXMaxYCorner,.layerMaxXMinYCorner,.layerMinXMinYCorner]
      
    }

}
