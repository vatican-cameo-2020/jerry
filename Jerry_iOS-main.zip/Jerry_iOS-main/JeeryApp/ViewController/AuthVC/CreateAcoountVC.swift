//
//  CreateAcoountVC.swift
//  JeeryApp
//
//  Created by daisy on 31/03/21.
//

import UIKit
import MaterialTextField
import GoogleSignIn
import AuthenticationServices
import FirebaseAuth

class CreateAcoountVC: BaseViewController {
    
    //MARK:-
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnJoin: UIButtonX!
    @IBOutlet weak var tfName: MFTextField!
    @IBOutlet weak var tfEmail: MFTextField!
    @IBOutlet weak var tfPassword: MFTextField!
    @IBOutlet weak var tfContactNumber: MFTextField!
    @IBOutlet weak var btnValidName: UIButton!
    @IBOutlet weak var btnValidEmail: UIButton!
    @IBOutlet weak var btnApple: UIButtonX!
    @IBOutlet weak var btnCountrySelect: UIButton!
    @IBOutlet weak var imgFlag: UIImageView!
    //   @IBOutlet weak var tfName2: MFTextField!
    
    //MARK:- Userdefined Properties
    private let authVM = AuthVM.init()
    fileprivate var currentNonce: String?
    var registerForm: SignupForm?
    let picker = MICountryPicker()
    
    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        setupSocialLogins()
    
    }
    
    func setupSocialLogins(){
        GIDSignIn.sharedInstance()?.presentingViewController = self
        GIDSignIn.sharedInstance()?.delegate = self
        if #available(iOS 13.0, *) {
            btnApple.isHidden = false
        } else {
            btnApple.isHidden = true
        }
    }
    
    //MARK:- Button Actions
    @IBAction func btnBackToLogin(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnJoin(_ sender: UIButtonX) {
        setUpRegistrationForm()
        removeErrors()
        if registerForm?.isValid() ?? false{
            authVM.loginType = .Email
            self.authVM.registerForm = registerForm ?? SignupForm()
            self.checkEmailExists()
          //  self.registerUser()
        }else{
            processError()
        }
    }
    
    @IBAction func btnShowHidePassword(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        tfPassword.isSecureTextEntry = !sender.isSelected
    }
    @IBAction func btnSocialLoginActions(_ sender: UIButton) {
        if sender.tag == 0{
            loginWithGoogle()
        }else if sender.tag == 1{
            loginWithFacebook()
        }else if sender.tag == 2{
            loginWithApple()
        }
    }
    
    @IBAction func tfEditingChanged(_ sender: UITextField) {
        setUpRegistrationForm()
        if sender == tfName{
            btnValidName.isHidden = (tfName.text ?? "").isEmpty
        }
        else if sender == tfEmail{
            btnValidEmail.isHidden = !(!(tfEmail.text ?? "").isEmpty && (tfEmail.text ?? "").isValidEmail)
        }
    }
    
    @IBAction func btnOpenCountryPicker(_ sender: UIButton) {
        picker.delegate = self
        picker.showCallingCodes = true
        picker.modalPresentationStyle = .overFullScreen
        navigationController?.present(picker, animated: true, completion: nil)

    }
    
    //MARK:- Userdefined Actions
    
    fileprivate func setUpRegistrationForm() {
        let contactNumber = (btnCountrySelect.titleLabel?.text ?? "")+(tfContactNumber.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "").replacingOccurrences(of: " ", with: "")
        registerForm = SignupForm(name: tfName.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "", email: (tfEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "").lowercased(), password: tfPassword.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "", phone: contactNumber)
    }
    
    /// Remove any previous text field errors 
    private func removeErrors(){
        tfEmail.setError(nil, animated: true)
        tfPassword.setError(nil, animated: true)
        tfName.setError(nil, animated: true)
        tfContactNumber.setError(nil, animated: true)
    }
    
     ///Check all validations and display errors
    private func processError(){
        let errorReason = registerForm!.errorReason()
        let localizedError = LocalErrors.init().errorWithDescription(errorReason.0)
        switch errorReason.1 {
        case .kFirstName:
            tfName.setError(localizedError, animated: true)
            break
        case .kEmail:
            
            tfEmail.setError(localizedError, animated: true)
            break
        case .kPassword:
            tfPassword.setError(localizedError, animated: true)
            break
        case .kPhone:
            tfContactNumber.setError(localizedError, animated: true)
            break
        default:
            break
        }
    }
    
    //MARK:- Social Logins
    func loginWithFacebook() {
        authVM.loginWithFacebook(fromViewController: self) { (status, creds) in
            if status{
                self.socialLogin(creds!, type: .Facebook)
            }
        }
    }
    
    func loginWithGoogle() {
        GIDSignIn.sharedInstance()?.signIn()
    }
    
    func loginWithApple() {
        if #available(iOS 13.0, *) {
            let appleIDProvider = ASAuthorizationAppleIDProvider()
            let request = appleIDProvider.createRequest()
            let nonce = authVM.randomNonceString()
            currentNonce = nonce
            request.requestedScopes = [.fullName, .email]
            request.requestedOperation = .operationImplicit
            request.nonce = authVM.sha256(nonce)
            let authorizationController = ASAuthorizationController(authorizationRequests: [request])
            authorizationController.delegate = self
            authorizationController.presentationContextProvider = self
            authorizationController.performRequests()
        }
    }
    
    //MARK:- Firebase Observer
    func sendRegistrationOTP(){
      showProgress()
        HitApi.share().sendOTP(view: self.view, phoneNumber: self.authVM.registerForm.phone) { (status, dict) in
            self.hideProgress()
            if status{
                let _: OtpVerificationVC = self.open(){
                    $0.authVM = self.authVM
                }
            }
        }
    }
    
    func checkEmailExists(){
        showProgress()
        self.firestoreRef.collection(FirebaseCollectionKeys.kUsers).whereField(FirebaseFieldKeys.User.email, isEqualTo: registerForm?.email)
            .rx
            .getDocuments()
            .subscribe(onNext: { (data) in
                let usr = data.documents
                if usr.count > 0{
                    self.toast(Constants.AppStrings.emailAlreadyExist)
                    self.hideProgress()
                }else{
                    self.checkPhoneExists()
                }
            }, onError: { (error) in
                self.checkPhoneExists()
            }).disposed(by: authVM.disposeBag)
    }
    
    func checkPhoneExists(){
        showProgress()
        self.firestoreRef.collection(FirebaseCollectionKeys.kUsers).whereField(FirebaseFieldKeys.User.contactNumber, isEqualTo: registerForm?.phone)
            .rx
            .getDocuments()
            .subscribe(onNext: { (data) in
                let usr = data.documents
                if usr.count > 0{
                    self.toast(Constants.AppStrings.phoneExist)
                    self.hideProgress()
                }else{
                    
                    self.sendRegistrationOTP()
                }
            }, onError: { (error) in
                
                self.sendRegistrationOTP()
            }).disposed(by: authVM.disposeBag)
    }
    
    func registerUser(){
        showProgress()
        authVM.registerUser(registerForm ?? SignupForm()) { (response) in
            if response.statusCode == 200{
                self.addloggedUser(response)
            }else{
                self.toast(response.message)
                self.hideProgress()
            }
        }
    }
    
    func fetchUserDetails(_ user: User?){
        authVM.fetchUserDetails(user) { response in
            self.hideProgress()
            if response.statusCode == 200{
                AppDefaults.userLogged = true
                AppDefaults.userEmail = AppDefaults.rememberMe ? (self.tfEmail.text ?? "").lowercased().trimmingCharacters(in: .whitespacesAndNewlines) : ""
                self.navigateToHome()
            }else{
                self.toast(response.message)
            }
        }
    }
    
    func socialLogin(_ authCreds: AuthCredential, type: LoginType){
        showProgress()
        authVM.socialCreds = authCreds
        authVM.loginType = type
        authVM.socialLogin() { response in
            if response.statusCode == 200{
                self.authVM.loginForm = LoginForm(email: response.signupForm.email)
                self.authVM.checkUserRegisteredAlready() { resp in
                    if resp.statusCode == 200{
                        if !(resp.userExists){
                            self.addloggedUser(response)
                        }else{
                            
                            self.fetchUserDetails(response.authUser)
                        }
                    }else{
                        self.hideProgress()
                        self.toast(resp.message)
                    }
                }
                self.hideProgress()
                
            }else{
                self.toast(response.message)
                self.hideProgress()
            }
        }
    }
    
    func addloggedUser(_ resp: AuthResponse){
        authVM.addUser(resp.signupForm, user: resp.authUser!) { response in
            self.hideProgress()
            if response.statusCode == 200{
                AppDefaults.userLogged = true
                AppDefaults.userEmail = AppDefaults.rememberMe ? (self.tfEmail.text ?? "").lowercased().trimmingCharacters(in: .whitespacesAndNewlines) : ""
               // self.navigateToHome()
                if AppDefaults.isFirstRun(){
                    let _: PremissionVC = self.customPresent(){
                        $0.navigateDelegate = self
                        $0.modalTransitionStyle = .crossDissolve
                    }
                }else{
                    let _: AddSpotVC = self.open(){
                        $0.fromRegisteration = true
                    }
                }
            }else{
                self.toast(response.message)
            }
        }
    }
}

//MARK:- PushScreen Delegate
extension CreateAcoountVC : PermissionDelegate {
    func allowPermission() {
        let _: AddSpotVC = open(){
            $0.fromRegisteration = true
        }
    }
}

// MARK: - GIDSignInDelegate
extension CreateAcoountVC: GIDSignInDelegate {
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if let error = error {
            if (error as NSError).code == GIDSignInErrorCode.hasNoAuthInKeychain.rawValue {
                print("The user has not signed in before or they have since signed out.")
            } else {
                print("\(error.localizedDescription)")
            }
            return
        }
        
        guard let authentication = user.authentication else { return }
        let credential = GoogleAuthProvider.credential(withIDToken: authentication.idToken,
                                                          accessToken: authentication.accessToken)
        self.socialLogin(credential, type: .Google)
    }
}

//MARK:- Apple Login Delegates
extension CreateAcoountVC: ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding{
    
    @available(iOS 13.0, *)
    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        self.showAlert(error.localizedDescription)
    }
    
    @available(iOS 13.0, *)
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        return self.view.window!
    }
    
    @available(iOS 13.0, *)
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        if let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential {
            
            let idToken = appleIDCredential.identityToken ?? Data()
            
            guard let nonce = self.currentNonce else {
                return
            }
            
            guard let idTokenString = String(data: idToken, encoding: .utf8) else {
                return
            }
            let credential = OAuthProvider.credential(withProviderID: "apple.com",
                                                      idToken: idTokenString,
                                                      rawNonce: nonce)
            let userName = (appleIDCredential.fullName?.givenName ?? "") + " " + (appleIDCredential.fullName?.familyName ?? "")
            self.authVM.appleDisplayName = userName
            self.socialLogin(credential, type: .Apple)
        }
    }
}

extension CreateAcoountVC: MICountryPickerDelegate{
    func countryPicker(_ picker: MICountryPicker, didSelectCountryWithName name: String, code: String) {}
    
    func countryPicker(_ picker: MICountryPicker, didSelectCountryWithName name: String, code: String, dialCode: String, countryFlagImage: UIImage) {
        btnCountrySelect.setTitle(dialCode, for: .normal)
        imgFlag.image = countryFlagImage
        picker.dismiss(animated: true, completion: nil)
    }
}
