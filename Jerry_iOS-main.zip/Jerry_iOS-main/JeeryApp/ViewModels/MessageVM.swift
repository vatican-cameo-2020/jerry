//
//  MessageVM.swift
//  JeeryApp
//
//  Created by John on 10/05/21.
//

import Foundation
import FirebaseFirestore

class MessageVM: ViewModel<MessageResponse>{
    
    //MARK:- Properties
    var firestoreRef = Firestore.firestore()
    var userDetails: UserDetails = UserDetails()
    var latitude: String = ""
    var longitude: String = ""
    var locationName: String = ""

    //MARK:- Fetch User Details
    
    func fetchUserDetails(completion: @escaping ((_ response: MessageResponse) -> ())){
        firestoreRef.collection(FirebaseCollectionKeys.kUsers)
        .document(fetchUserData()?.userId ?? "")
        .rx
        .getDocument()
        .subscribe(onNext: { document in
            if let data = document.data(){
                var userData = UserDetails.init()
                userData.deserilize(values:data)
                self.userDetails = userData
                completion(MessageResponse(statusCode: 200))
            }
        }, onError: { error in
            completion(MessageResponse(statusCode: 0, message: error.localizedDescription))
        }).disposed(by: disposeBag)
    }
                                                 
    func stampLocationForMe(completion: @escaping ((_ response: MessageResponse) -> ())){
        
        let ref = firestoreRef.collection(FirebaseCollectionKeys.kUsers).document(fetchUserData()?.userId ?? "").collection(FirebaseFieldKeys.User.notifications).document()
        
        let notif = Messages(roomType: .kStamp, msgType: .kText, createdAt: Date.timeStamp, senderId: fetchUserData()?.userId ?? "", senderName: fetchUserData()?.name ?? "", senderImage: fetchUserData()?.profilePicture ?? "")
        
        ref.rx.setData(notif.serilize())
        .subscribe(onNext: { _ in
            completion(MessageResponse(statusCode: 200))
        }, onError: { error in
            completion(MessageResponse(statusCode: 0, message: error.localizedDescription))
        }).disposed(by: disposeBag)
    }
    
    
    //MARK:- User Spots Editing
    func addSpot(_ spot: SpotDetail, completion: @escaping ((_ response: MessageResponse) -> ())){
        
        let ref = firestoreRef.collection(FirebaseCollectionKeys.kUsers).document(fetchUserData()?.userId ?? "").collection(FirebaseCollectionKeys.kSpots).document()
        
        var selectedSpot = spot
        selectedSpot.spotId = ref.documentID

        ref.rx.setData(selectedSpot.serilize())
            .subscribe(onNext: { (_) in
             //   completion(SpotsResponse(statusCode: 200, spotRespType: .Add_Spot))
            }, onError: { (error) in

               // completion(SpotsResponse(statusCode: 0, message: error.localizedDescription))
            }).disposed(by: disposeBag)
    }
}
