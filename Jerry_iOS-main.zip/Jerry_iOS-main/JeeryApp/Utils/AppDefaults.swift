//
//  AppSettings.swift
//  Camo
//
//  Created by SachTech on 29/02/20.
//  Copyright © 2020 SachTech. All rights reserved.
//

import Foundation

struct AppDefaults{
    
    static var firstRun: Bool = false
    
    //MARK:- FCM Token
    static var fcmToken: String{
        set{
            UserDefaults.standard.set(newValue, forKey: Constants.PrefKeys.kFCMToken)
        }
        get{
            return UserDefaults.standard.string(forKey:  Constants.PrefKeys.kFCMToken) ?? ""
        }
    }

    //MARK:- User Logged In
    static var userLogged: Bool{
        set{
            UserDefaults.standard.set(newValue, forKey: Constants.PrefKeys.kUserLogin)
        }
        get{
            return UserDefaults.standard.bool(forKey: Constants.PrefKeys.kUserLogin)
        }
    }
    
    //MARK:- Remember Me
    static var rememberMe: Bool{
        set{
            UserDefaults.standard.set(newValue, forKey: Constants.PrefKeys.kRememberMe)
        }
        get{
            return UserDefaults.standard.bool(forKey: Constants.PrefKeys.kRememberMe)
        }
    }
    
   
    
    //MARK:- User Prefs
    static var userEmail: String{
        set{
            UserDefaults.standard.set(newValue, forKey: Constants.PrefKeys.kEmail)
        }
        get{
            return UserDefaults.standard.string(forKey:  Constants.PrefKeys.kEmail) ?? ""
        }
    }
    
    
//    static var userPass: String{
//        set{
//            UserDefaults.standard.set(newValue, forKey: PrefKeys.kPassword)
//        }
//        get{
//            return UserDefaults.standard.string(forKey:  PrefKeys.kPassword) ?? ""
//        }
//    }
    
    static func isFirstRun() -> Bool{

        if let isAppAlreadyLaunchedOnce = UserDefaults.standard.string(forKey: Constants.PrefKeys.kFirstRun){
            print("App already launched : \(isAppAlreadyLaunchedOnce)")
            firstRun = false
            return false
            
        }else{
            UserDefaults.standard.set(true, forKey: Constants.PrefKeys.kFirstRun)
            print("App launched first time")
            firstRun = true
            return true
        }
    }

    //MARK:- Clear App Defaults
    static func clearAppDefaults(){
        
        userLogged = false
        userEmail = rememberMe ? userEmail : ""
        UserDefaults.standard.set(nil, forKey: Constants.PrefKeys.kUserData)
        UserDefaults.standard.set(false, forKey: Constants.PrefKeys.kFirstRun)
    }
}
