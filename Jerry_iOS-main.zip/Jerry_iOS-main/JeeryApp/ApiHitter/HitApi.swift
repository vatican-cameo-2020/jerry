
//I am having some issue with this locking up the Global Cache unit. Can you make the ? button take you to a screen where I can configure the IP and port so I can run some tests?
//
//Also, the right arrow is still oversized.
import Foundation
import Alamofire
import UIKit
import NVActivityIndicatorView

class HitApi{
    
    public static let BASE_URL = Constants.ApiEnds.baseUrl
    var manager: SessionManager!
    private static var api:HitApi!
    private static var apiLinker:ApiLinker!
    let defaults:UserDefaults = UserDefaults.standard
    
    class func share() -> HitApi{
        if api == nil {
            api = HitApi()
            apiLinker = ApiLinker()
        }
        return api
    }
    fileprivate var maskView : UIView!
    fileprivate var indicatorView : NVActivityIndicatorView!
   
    func sendOTP(view:UIView, phoneNumber: String, completion:@escaping (Bool,String)->Void){

        let url = Constants.ApiEnds.baseUrl+Constants.ApiEnds.sendOTP
        
        HitApi.apiLinker.setProgress(isProgress: false).requestMethod(method: .post).execute(view: view, url: url) { () -> [String : AnyObject]? in

            let params = [
                "phone_no": phoneNumber
            ] as [String: AnyObject]
            return params
        } onResponse: { (response) in
            if let response = response as? [String:Any]{
                let status = response["status"] as? Bool ?? false
                let message = response["message"] as? String ?? ""
                if status{
                   completion(status,message)
                }else{
                    completion(status,message)
                }
            }
        } onError: { (error) in
            completion(false, error ?? "")
        }        
    }
    
    func verifyOTP(view:UIView, phoneNumber: String, otp: String, completion:@escaping (Bool,String)->Void){

        let url = Constants.ApiEnds.baseUrl+Constants.ApiEnds.verifyOTP
        
        HitApi.apiLinker.setProgress(isProgress: false).requestMethod(method: .post).execute(view: view, url: url) { () -> [String : AnyObject]? in

            let params = [
                "phone_no": phoneNumber,
                "otp": otp
            ] as [String: AnyObject]
            return params
        } onResponse: { (response) in
            if let response = response as? [String:Any]{
                let status = response["status"] as? Bool ?? false
                let message = response["message"] as? String ?? ""
                if status{
                    completion(status,message)
                }else{
                    completion(status,message)
                }
            }
        } onError: { (error) in
            completion(false, error ?? "")
        }
    }
}
