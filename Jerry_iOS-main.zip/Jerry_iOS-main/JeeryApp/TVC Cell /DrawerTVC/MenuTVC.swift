//
//  tvcDrawer.swift
//  JeeryApp
//
//  Created by daisy on 05/04/21.
//

import UIKit

class MenuTVC: UITableViewCell {

    @IBOutlet weak var imgService: UIImageView!
    @IBOutlet weak var lblService: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
