//
//  FirebaseFields.swift
//  JeeryApp
//
//  Created by John on 23/04/21.
//

import Foundation

struct FirebaseCollectionKeys{
    static let kUsers: String = "Users"
    static let kSpots: String = "Spots"
    static let kReport: String = "Reports"
    static let kChatRooms: String = "ChatRooms"
    static let kMessages: String = "Messages"
}
