//
//  tvcReceiverImageSend.swift
//  JeeryApp
//
//  Created by daisy on 10/04/21.
//

import UIKit

class tvcReceiverImageSend: UITableViewCell {

    @IBOutlet weak var lblImgRecieve: UILabel!
    @IBOutlet weak var imgRecieve: UIImageViewX!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        bounds()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func bounds(){
        imgRecieve.layer.cornerRadius = 15
        imgRecieve.layer.maskedCorners = [.layerMaxXMaxYCorner,.layerMaxXMinYCorner,.layerMinXMinYCorner]
    }
}
