//
//  SwipeUpVC.swift
//  JeeryApp
//
//  Created by daisy on 12/04/21.
//

import UIKit
import MaterialTextField

class SwipeUpVC: UIViewController, UITextFieldDelegate {
 
    @IBOutlet weak var tfSearchBar: MFTextField!
    @IBOutlet weak var tvList: DynamicSizeTableView!
    
    var arrLocation = ["Patiala","Chandigarh","Mohali"]
    override func viewDidLoad() {
        super.viewDidLoad()
        tfSearchBar.delegate = self
        tvList.isHidden = true
        setDelegates()
        tfSearchBar.placeholderColor = UIColor(named: "themeWhite")
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        tvList.isHidden = false
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        tfSearchBar.isSelected = false
//        tvList.isHidden = true
    }
  
    func setDelegates(){
        let nibNameuser = UINib(nibName: "tvcSwipeUp", bundle:nil)
        self.tvList.register(nibNameuser, forCellReuseIdentifier: "tvcSwipeUp")
        tvList.delegate = self
        tvList.dataSource = self
    }
   
}
extension SwipeUpVC : UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrLocation.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tvcSwipeUp", for: indexPath) as! tvcSwipeUp
        cell.lblLocationName.text = arrLocation[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tvList.isHidden = true
        tfSearchBar.isSelected = false
    }
    
}
