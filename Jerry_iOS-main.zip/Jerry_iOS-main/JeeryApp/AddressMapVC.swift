//
//  MapwithSerchVC.swift
//  JeeryApp
//
//  Created by daisy on 12/04/21.
//

import UIKit
import MapKit
import CoreLocation

enum Shift{
    case GotoMessage
    case GotoViewSpot
}

protocol MapViewDelegate {
    func onLocationFetched(_ location: LocationAddress)
}


class AddressMapVC: BaseViewController, CLLocationManagerDelegate{

    //MARK:- Outlets
    @IBOutlet var vwBottom: UIViewX!
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var imgLocPin: UIImageViewX!
    @IBOutlet weak var lblLocationName: UILabel!
    
    //MARK:- Userdefined Variables
    var mapDelegate: MapViewDelegate?
    var location: LocationAddress = LocationAddress()
    var address: String?
    var locations: [Double] = []
    var currentLocFetched: Bool = false


    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        vwBottom.layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner]
        setInitialLocation()
}
    @IBAction func btnConfirm(_ sender: UIButtonX) {

        mapDelegate?.onLocationFetched(self.location)
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnCurrentLocationAction(_ sender: UIButton) {
        setCurrentLocation()
    }
    
    
    //MARK:- Userdefined Functions
    
    fileprivate func setInitialLocation() {
        if locations.isEmpty{
            setCurrentLocation()
        }else if locations.first == 0.0 || locations.last == 0.0 {
            setCurrentLocation()
        }
        else{
            let coordinates: CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: locations[0], longitude: locations[1])
            let region = MKCoordinateRegion(center: coordinates, latitudinalMeters: 500, longitudinalMeters: 500)
            self.mapView.setRegion(region, animated: true)
            self.currentLocFetched = true
        }
    }
    
    fileprivate func setCurrentLocation() {
        LocationHelper.shared.getLocation { (location, error) in
            guard let loc = location else{
                self.toast("Unable to fetch location")
                return
            }
            self.currentLocFetched = true
            let region = MKCoordinateRegion(center: loc.coordinate, latitudinalMeters: 500, longitudinalMeters: 500)
            self.mapView.setRegion(region, animated: true)
        }
    }
    
    fileprivate func fetchLocation(location:CLLocationCoordinate2D) {
        LocationHelper.shared.getReverseGeoCodedLocation(location: CLLocation.init(latitude: location.latitude, longitude: location.longitude)) { (location, placemark, error) in
            self.location.latitude = "\(Double(location?.coordinate.latitude ?? 0))"
            self.location.longitude = "\(Double(location?.coordinate.longitude ?? 0))"
            self.location.street = (placemark?.postalAddress?.street ?? "").isEmpty ? placemark?.name ?? "" : "\(placemark?.postalAddress?.street), \(placemark?.name ?? "")"
            self.location.city = placemark?.locality ?? ""
            self.location.country = placemark?.country ?? ""
            self.location.state = placemark?.postalAddress?.state ?? ""
            
            var address = [ self.location.street, self.location.city, self.location.state, self.location.country]
            address.removeAll(where: {$0.isEmpty})
            self.location.address = address.joined(separator: ", ")
            self.lblLocationName.text = address.joined(separator: ", ")
            self.location.pincode = placemark?.postalCode ?? ""

            self.address = address.joined(separator: ", ")

        }
    }
}
extension AddressMapVC: MKMapViewDelegate{
    func mapView(_ mapView: MKMapView, regionDidChangeAnimated animated: Bool) {
        if currentLocFetched{
          fetchLocation(location: mapView.centerCoordinate)
        }
    }
}
