//
//  ViewVC.swift
//  JeeryApp
//
//  Created by daisy on 03/04/21.
//

import UIKit

class ViewVC: UIViewController {
    
    var arrImage = [#imageLiteral(resourceName: "ashish'gf.jpeg"),#imageLiteral(resourceName: "dimpal'bf.jpeg"),#imageLiteral(resourceName: "girl.jpeg"),#imageLiteral(resourceName: "model"),#imageLiteral(resourceName: "vishal'gf.jpeg"),#imageLiteral(resourceName: "dimpal'bf")]
    var arrIcon = [#imageLiteral(resourceName: "message-square"),#imageLiteral(resourceName: "smallsetting"),#imageLiteral(resourceName: "Icon image"),#imageLiteral(resourceName: "smallsetting")]
    var arrname = ["Diane Tucker","Andrew Moore","Sara Dunn","Laura Barnett","Andrew Moore","Tyler"]
    var arrMessage = ["Music","","Picture","Video","",""]
    var arrDate = ["","","","5 hours ago","8 hours ago",""]
    var arrPinedMessage = ["Tommy pinned a group message","You stamped","Samantha pinned a photo w/ you","Mark stamped"]
    var arrUsername = ["@ Elysian Park","@ Nature’s Park","@ Santa Monica Pier","@ Irish Club"]
    
    
    @IBOutlet weak var viewStack: UIStackView!
    @IBOutlet weak var tvView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapGesture))
        tap.numberOfTapsRequired = 1
        viewStack.addGestureRecognizer(tap)
        setDelegates()
    }
    
    
    @IBAction func btnCancel(_ sender: UIButton) {
    }
    @objc func tapGesture(){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MultipleTypeChatVC") as! MultipleTypeChatVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func setDelegates(){
        let nibNameuser = UINib(nibName: "tvcViewUserCell", bundle:nil)
        self.tvView.register(nibNameuser, forCellReuseIdentifier: "tvcViewUserCell")
        let nibNameDirection = UINib(nibName: "tvcViewDirection", bundle:nil)
        self.tvView.register(nibNameDirection, forCellReuseIdentifier: "tvcViewDirection")
        tvView.delegate = self
        tvView.dataSource = self
        
    }
    
}
extension ViewVC : UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return arrPinedMessage.count
        }
        else{
            return arrname.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            if indexPath.row == 1{
                let cell = tableView.dequeueReusableCell(withIdentifier: "tvcViewDirection", for: indexPath) as! tvcViewDirection
                cell.imgIcon.image = arrIcon[indexPath.row]
                cell.lblGroup.text = arrPinedMessage[indexPath.row]
                cell.lblUserName.text = arrUsername[indexPath.row]
                cell.btnDirection.isHidden = true
                return cell
            }
            else{
                let cell = tableView.dequeueReusableCell(withIdentifier: "tvcViewDirection", for: indexPath) as! tvcViewDirection
                cell.imgIcon.image = arrIcon[indexPath.row]
                if indexPath.row == 3{
                    cell.lblGroup.attributedText = arrPinedMessage[indexPath.row].underlineString(highlightedText: "stamped")
                    
                }
                else{
                    cell.lblGroup.text = arrPinedMessage[indexPath.row]
                }
                cell.lblUserName.text = arrUsername[indexPath.row]
                return cell
            }
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "tvcViewUserCell", for: indexPath) as! tvcViewUserCell
            cell.imgUser.image = arrImage[indexPath.row]
            cell.lblDate.text = arrDate[indexPath.row]
            cell.lblName.text = arrname[indexPath.row]
            cell.lblitem.text = arrMessage[indexPath.row]
            if indexPath.row > 2{
                cell.imgMarker.isHidden = true
            }
            else{
                cell.imgMarker.isHidden = false
            }
            
            return cell
        }
        
        
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0{
            if indexPath.row == 3{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "StampedMsgVC") as! StampedMsgVC
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
        else {
            if indexPath.row == 2{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "MultipleTypeChatVC") as! MultipleTypeChatVC
                self.navigationController?.pushViewController(vc, animated: true)
            }
            else if indexPath.row == 5 {
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "MultipleTypeChatVC") as! MultipleTypeChatVC
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
}
extension String
{
    func highLightString(highlightedText:String,color:UIColor) -> NSAttributedString
    {
        let highLightText = highlightedText
        let range = (self as NSString).range(of: highLightText)
        let attributedText = NSMutableAttributedString.init(string: self)
        attributedText.addAttribute(NSAttributedString.Key.foregroundColor, value: color , range: range)
        return attributedText
    }
    
    func highLightBoldString(highlightedText:String,size:CGFloat,color:UIColor) -> NSAttributedString
    {
        let highLightText = highlightedText
        let range = (self as NSString).range(of: highLightText)
        let attributedText = NSMutableAttributedString.init(string: self)
        attributedText.addAttribute(NSAttributedString.Key.font, value: UIFont(name: "Poppins-SemiBold", size: size)! , range: range)
        attributedText.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.thick.rawValue, range: range)
        attributedText.addAttribute(NSAttributedString.Key.foregroundColor, value: color , range: range)
        return attributedText
    }
    func underlineString(highlightedText:String) -> NSAttributedString
    {
        let highLightText = highlightedText
        let range = (self as NSString).range(of: highLightText)
        let attributedText = NSMutableAttributedString.init(string: self)
        attributedText.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.thick.rawValue, range: range)
        attributedText.addAttribute(NSAttributedString.Key.underlineColor, value: UIColor.black, range: range)
        return attributedText
    }
}
