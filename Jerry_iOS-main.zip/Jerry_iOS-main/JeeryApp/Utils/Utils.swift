//
//  Utils.swift
//  Camo
//
//  Created by SachTech on 25/02/20.
//  Copyright © 2020 SachTech. All rights reserved.
//

import Foundation

func fetchUserData() -> UserDetails?{
    let defaults = UserDefaults.standard
    if let decoded  = defaults.data(forKey: Constants.PrefKeys.kUserData){
        do{
            if let user = try NSKeyedUnarchiver.unarchivedObject(ofClass: PrefUser.self, from: decoded){ //unarchiveObject(with: decoded) as? PrefUser{
                let usr = UserDetails(userId: user.userId, email: user.email, name: user.name, profilePicture: user.profilePicture, contactNumber: user.contactNumber, loginType: LoginType(rawValue: user.loginType) ?? .Email, fcmToken: user.fcmToken, birthday: user.birthday.toDate(), address: user.address, latitude: user.latitude, longitude: user.longitude)
                return usr
            }else{
                return nil
            }
        }catch{
            return nil
        }
    }
    else{
        return nil
    }
}

func saveUserData(_ user: UserDetails){
    
    let prefUser = PrefUser(userId: user.userId, email: user.email, name: user.name, profilePicture: user.profilePicture, contactNumber: user.contactNumber, loginType: user.loginType.rawValue, fcmToken: AppDefaults.fcmToken, birthday: user.birthday?.getFormattedDate() ?? "", address: user.address, latitude: user.latitude, longitude: user.longitude)

    let defaults = UserDefaults.standard
    do{
        let encodedData: Data = try NSKeyedArchiver.archivedData(withRootObject: prefUser, requiringSecureCoding: false)
        defaults.set(encodedData, forKey: Constants.PrefKeys.kUserData)
        defaults.synchronize()
    }catch{
        
    }
}

func clearDefaults(){
    let defaults = UserDefaults.standard
    let domain = Bundle.main.bundleIdentifier!
    defaults.removePersistentDomain(forName: domain)
    defaults.synchronize()
}

class PrefUser: NSObject, NSCoding, NSSecureCoding{
    static var supportsSecureCoding: Bool = true
    var userId: String = ""
    var email: String = ""
    var name: String = ""
    var profilePicture: String = ""
    var contactNumber: String = ""
    var loginType: String = ""
    var fcmToken: String = ""
    var birthday: String = ""
    var address: String = ""
    var latitude: String = ""
    var longitude: String = ""
    
    init(userId: String, email: String, name: String, profilePicture: String, contactNumber: String, loginType: String, fcmToken: String, birthday: String = "", address: String = "", latitude: String = "", longitude: String = "") {
        self.userId = userId
        self.email = email
        self.name = name
        self.profilePicture = profilePicture
        self.contactNumber = contactNumber
        self.loginType = loginType
        self.fcmToken = fcmToken
        self.birthday = birthday
        self.address = address
        self.latitude = latitude
        self.longitude = longitude
    }

func encode(with aCoder: NSCoder) {
    aCoder.encode(userId, forKey: "userId")
    aCoder.encode(email, forKey: "email")
    aCoder.encode(name, forKey: "name")
    aCoder.encode(profilePicture, forKey: "profilePicture")
    aCoder.encode(contactNumber, forKey: "contactNumber")
    aCoder.encode(loginType, forKey: "loginType")
    aCoder.encode(fcmToken, forKey: "fcmToken")
    aCoder.encode(birthday, forKey: "birthday")
    aCoder.encode(address, forKey: "address")
    aCoder.encode(latitude, forKey: "latitude")
    aCoder.encode(longitude, forKey: "longitude")
}
    

required convenience init?(coder aDecoder: NSCoder) {
    let userId = aDecoder.decodeObject(forKey: "userId") as? String ?? ""
    let name = aDecoder.decodeObject(forKey: "name") as? String ?? ""
    let email = aDecoder.decodeObject(forKey: "email") as? String ?? ""
    let profilePicture = aDecoder.decodeObject(forKey: "profilePicture") as? String ?? ""
    let contactNumber = aDecoder.decodeObject(forKey: "contactNumber") as? String ?? ""
    let loginType = aDecoder.decodeObject(forKey: "loginType") as? String ?? ""
    let fcmToken = aDecoder.decodeObject(forKey: "fcmToken") as? String ?? ""
    let birthday = aDecoder.decodeObject(forKey: "birthday") as? String ?? ""
    let address = aDecoder.decodeObject(forKey: "address") as? String ?? ""
    let latitude = aDecoder.decodeObject(forKey: "latitude") as? String ?? ""
    let longitude = aDecoder.decodeObject(forKey: "longitude") as? String ?? ""

    self.init(userId: userId, email: email, name: name, profilePicture: profilePicture, contactNumber: contactNumber, loginType: loginType, fcmToken: fcmToken, birthday: birthday, address: address, latitude: latitude, longitude: longitude)
    }
}


func callOnThread(thread:DispatchQoS.QoSClass,completion:@escaping()->()){
    DispatchQueue.global(qos: thread).async {
        completion()
    }
}

func callOnMain(completion:@escaping()->()){
    DispatchQueue.main.async {
        completion()
    }
}
