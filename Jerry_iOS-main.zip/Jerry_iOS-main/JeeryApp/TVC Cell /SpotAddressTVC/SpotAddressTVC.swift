//
//  tvcAddressList.swift
//  JeeryApp
//
//  Created by daisy on 06/04/21.
//

import UIKit

class SpotAddressTVC: UITableViewCell {

    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblSpotName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func setAddresssInfo(_ spot: SpotDetail){
        lblAddress.text = spot.address
        lblSpotName.text = spot.spotName
    }
    
}
