//
//  LoginForm.swift
//  Camo
//
//  Created by SachTech on 20/02/20.
//  Copyright © 2020 SachTech. All rights reserved.
//

import Foundation

struct LoginForm:Validator {

    var email:String = ""
    var password:String = ""

    func isValid() -> Bool {

        return !email.isEmpty //&& email.isValidEmail
    }

    func errorReason() -> (String, ValidatorKeys) {
        if email.isEmpty{
            return (Constants.AppStrings.emptyEmail,ValidatorKeys.kEmail)
        }
//        else if !email.isValidEmail{
//            return (Constants.AppStrings.notValidEmail,ValidatorKeys.kEmail)
//        }
        else {
            return (Constants.AppStrings.unknownError,ValidatorKeys.kUnknown)
        }
    }
}
