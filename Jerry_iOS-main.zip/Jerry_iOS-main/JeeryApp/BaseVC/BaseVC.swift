//
//  BaseVC.swift
//  EverArk
//
//  Created by SachTech on 01/07/20.
//  Copyright © 2020 SachTech. All rights reserved.
//


import Foundation
import UIKit
import SDWebImage
import KYDrawerController
import Toast
import Firebase

class BaseViewController: UIViewController {
    
    //MARK:- Userdefined variables
    let delegate = UIApplication.shared.delegate as! AppDelegate
    var progressView = CustomProgressView()
    let auth = Auth.auth()
    var firestoreRef = Firestore.firestore()

    //MARK:- Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        hideNavBar()
    }

    
    //MARK:- Navigation Bar Setup
    func hideNavBar(){
        navigationController?.navigationBar.isHidden = true
    }
    
    func showNavBar(){
        navigationController?.navigationBar.isHidden = false
    }

    func setTransparentNavBar(){
        navigationController?.transparentNavBar()
    }
    
    fileprivate func setTitleTextStyle() {
           self.navigationController?.navigationBar.titleTextAttributes =
               [NSAttributedString.Key.foregroundColor: UIColor(named: "themeGreen1")!,
                NSAttributedString.Key.font: UIFont(name: "Poppins-Medium", size: 20)!]
    }
    
    //MARK:- Alert Date Picker
    func presentAlertDatePicker(completion:@escaping (Date)->Void){
        let myDatePicker: UIDatePicker = UIDatePicker()
        myDatePicker.datePickerMode = .date
        myDatePicker.timeZone = NSTimeZone.local
        if #available(iOS 13.4, *) {
            myDatePicker.preferredDatePickerStyle = .wheels
        }
        myDatePicker.frame = CGRect(x: 5, y: 40, width: 260, height: 190)
        let alertController = UIAlertController(title: "Pick Date \n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertController.Style.alert)
        alertController.view.addSubview(myDatePicker)
        let selectAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { _ in
            print("Selected Date: \(myDatePicker.date)")
            completion(myDatePicker.date)
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
        alertController.addAction(selectAction)
        alertController.addAction(cancelAction)
        present(alertController, animated: true, completion:{})
    }

    //MARK:- Alerts And Toast
    func toast(_ message:String){
        if let view = AppDelegate.share().window?.rootViewController?.view{
            view.makeToast(message)
        }else{
            self.view.makeToast(message)
        }
    }
    
    func navigateToHome(){
        let story = UIStoryboard(name: "Main", bundle:nil)
        let vc = story.instantiateViewController(withIdentifier: "drawerNavigation") as! UINavigationController
        UIApplication.shared.windows.first?.rootViewController = vc
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    func showAlert(title: String = "Jerry",_ message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        OKAction.titleTextColor = Constants.AppAssets.themeGrey
        alertController.addAction(OKAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    
    fileprivate func openActivityController(_ items: [Any]) {
        let activityViewController = UIActivityViewController(activityItems: items, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
        
        self.present(activityViewController, animated: true, completion: nil)
    }

    

    func openUrl(_ urlString:String) {
        let url = URL(string: urlString)!
        if #available(iOS 10.0, *) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        } else {
            UIApplication.shared.openURL(url)
        }
    }
    
    //MARK:- Custom Progress Setup
    func showProgress(_ text: String = "Loading"){
        callOnMain {
            let view = self.delegate.window?.rootViewController?.view ?? self.view
            self.progressView = CustomProgressView(frame: view?.frame ?? self.view.frame)
            self.progressView.setLoader(text)
            if !(view?.subviews.contains(self.progressView) ?? false){
                view?.addSubview(self.progressView)}
        }
    }
    
    func hideProgress(){
         callOnMain {
             self.progressView.removeFromSuperview()
         }
    }

}

//MARK:- UIImagePicker Delegates
extension BaseViewController: UIImagePickerControllerDelegate & UINavigationControllerDelegate{
    
    func presentPickerSelector(){
        
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.allowsEditing = true
        
        let alert = UIAlertController(title: "Select image from", message: nil, preferredStyle:    UIAlertController.Style.actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { (handler) in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) {
                 picker.sourceType = UIImagePickerController.SourceType.camera
                 picker.showsCameraControls = true
                 self.present(picker, animated: true, completion: nil)
             }
             else
             {
                 let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
                 alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                 self.present(alert, animated: true, completion: nil)
             }
        }
    
        let galleryAction = UIAlertAction(title: "Gallery", style: .default) { (handler) in
            picker.sourceType = .photoLibrary
            self.present(picker, animated: true, completion: nil)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (handler) in
            
        }
        alert.addAction(cameraAction)
        alert.addAction(galleryAction)
        alert.addAction(cancelAction)
        present(alert, animated: true)
    }
    
    
}
