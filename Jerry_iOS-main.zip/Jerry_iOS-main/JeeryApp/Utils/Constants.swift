//
//  ApiConstants.swift
//  EverArk
//
//  Created by Sachtech on 14/10/20.
//  Copyright © 2020 SachTech. All rights reserved.
//

import Foundation
import UIKit

struct Constants{
    
    struct AppStrings{
        static let unknownError: String = "Unknown error"
        static let emptyEmail: String = "Enter email"
        static let notValidEmail: String = "Not a valid email"
        static let enterName: String = "Enter name"
        static let emptyPassword: String = "Enter password"
        static let notValidPassword: String = "Not a valid password"
        static let emptyPhone: String = "Enter contact number"
        static let notValidPhone: String = "Not a valid contact number"
        static let imageTooBig: String = "This file is too large to upload. The maximum supported file size is: 20 MB"
        static let profileUpdated: String = "Profile updated successfully"
        static let cancel: String = "Cancel"
        static let ok: String = "Ok"
        static let yes: String = "Yes"
        static let no: String = "No"
        static let confirmLogout: String = "Are you sure want to log out?"
        static let addYourSpots: String = "Add your Spots"
        static let termsConditions: String = "Terms & Conditions"
        static let privacyPolicy: String = "Privacy Policy"
        static let reportHelp: String = "Report & Help"
        static let logout: String = "Logout"
        static let resetEmailPassword: String = "An email with a reset password link has been sent to you."
        static let emptyEmailNumber: String = "Enter email or your phone number"
        static let emailAlreadyExist: String = "Email already registered"
        static let phoneExist: String = "Phone number already registered"
        static let selectLocationName: String = "Enter a name for the marked location"
        
        static let emptySpotName: String = "Enter location name"
        static let emptyStreet: String = "Enter street"
        static let emptyCity: String = "Enter city"
        static let emptyState: String = "Enter state"
        static let emptyZip: String = "Enter zip code"
        static let emptyIssue: String = "Write a review"
        static let reviewSubmitSuccess: String = "Review submitted successfully"
    }
    
    struct AppAssets {
        //Image Assets
        static let dummyPlaceholder: UIImage = UIImage(named: "dummy_placeholder") ?? UIImage()
        static let userAvtar: UIImage = UIImage(named: "avtar") ?? UIImage()
        
        //Color Assets
        static let cellBackground: UIColor = UIColor(named: "cellBackground") ?? .lightText
        static let themeGrey: UIColor = UIColor(named: "themeGrey") ?? .gray
    }
    
    struct PrefKeys {
    
        public static let kFCMToken = "fcmToken"
        public static let kDeviceKey = "com.sachtech.jerry"
        public static let kUserLogin = "isUserLogin"
        public static let kErrorDomain:String = "Jerry"
        public static let kErrorCode:Int = 100
        public static let kRememberMe = "rememberMe"

        public static let kUserData = "userData"
        public static let kFirstRun = "isFirstRun"
        public static let kEmail = "app_email"
        public static let kPassword = "app_pass"
        public static let kProfilePicture = "profile_picture"

    }
    
    struct SocialKeys{
        static let googleClientId: String = "1035964149159-bstvlsknq37pcr18rmok69qeuokvbek9.apps.googleusercontent.com"
        //"370370885152-i6d8gvke735ccpshta6g8khhip8fcfu0.apps.googleusercontent.com"
        static let facebookAppId: String = "131931418913612"
        static let facebookAppSecret: String = "9cb7c2f39897066d4d822c2bd63f4baf"
        static let termsConditionsURL: String = "https://www.websitepolicies.com/policies/view/nYFFO6st"
        static let privacyPolicyURL:String = "https://www.websitepolicies.com/policies/view/UPIAacG2"
    }
    
    //MARK:- API End Points
    struct ApiEnds{

        static let baseUrl: String = "http://122.160.70.200:5009/api/v1"
        static let sendOTP: String = "/users/register"
        static let verifyOTP: String = "/users/verify"
    }
    
    //MARK:- Notifications Points
    struct NotifNames{
        static let navigateToTabBar: NSNotification.Name = NSNotification.Name("goToButtonTabs")
        static let navigateBackAction: NSNotification.Name = NSNotification.Name("navigateBackAction")
        static let changeNavigation: NSNotification.Name = NSNotification.Name("changeNavigation")
    }
    
    struct Locations{
        static let googleApiKey: String = "AIzaSyA8BbLiH2vnQ4dvm9ygAgED1KW2tCYnYMo"
        static let locationUpdated: String = "locationUpdated"
    }
    
    //MARK:- Sockets Keys
    struct SocketKeys {
        static let socketUrl: String = "http://3.12.142.225:3008"
        //static let socketUrl: String = "http://192.168.0.32:3008"
        static let joinChat: String = "join"
        static let sendMessage: String = "send_message"
        static let receivedMessage: String = "group_new_message"
        static let startTyping: String = "start_typing"
        static let stopTyping: String = "stop_typing"
    }
    
    struct TableCells {
        static let drawerMenuTVC: String = "MenuTVC"
        static let spotTVC: String = "SpotsTVC"
        static let contactsTVC: String = "ContactsTVC"
        static let spotAddressTVC: String = "SpotAddressTVC"
    }
}
